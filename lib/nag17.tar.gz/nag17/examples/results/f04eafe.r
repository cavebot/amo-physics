 F04EAF Example Program Results
 
 Solution vector
    -4.000    7.000    3.000   -4.000   -3.000
