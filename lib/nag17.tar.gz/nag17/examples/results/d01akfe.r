 D01AKF Example Program Results
 
 A      - lower limit of integration =      .0000
 B      - upper limit of integration =     6.2832
 EPSABS - absolute accuracy requested =   .00D+00
 EPSREL - relative accuracy requested =   .10D-02
 
 RESULT - approximation to the integral =   -.20967
 ABSERR - estimate of the absolute error =   .44D-13
 KOUNT  - number of function evaluations =  427
 IW(1)  - number of subintervals used =    4
