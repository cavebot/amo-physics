 G04BCF Example Program Results
 
  ANOVA TABLE
 
 Rows         4.     29.4231      7.3558      9.0266     .0013
 Columns      4.     22.9950      5.7487      7.0545     .0037
 Treatments   4.       .5423       .1356       .1664     .9514
 Residual    12.      9.7788       .8149
 Total       24.     62.7392
 
  Treatment means
 
    7.3180    7.2440    7.2060    6.9000    7.2600
 
 S.E. of difference (orthogonal design) =      .5709
