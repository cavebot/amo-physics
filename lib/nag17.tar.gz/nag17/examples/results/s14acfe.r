 S14ACF Example Program Results
 
        X        psi(X)-log(X)
 
        .1000        -8.1212
        .5000        -1.2704
       3.6000         -.1453
       8.0000         -.0638
