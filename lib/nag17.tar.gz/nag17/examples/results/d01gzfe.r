 D01GZF Example Program Results
 
 NDIM =  4 NP1 =    89 NP2 =    11
 
 Coefficients =    1.  102.  614.  951.
