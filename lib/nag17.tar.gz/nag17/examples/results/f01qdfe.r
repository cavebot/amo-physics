 F01QDF Example Program Results
 
 Matrix  Q'*B
  -1.0000  -1.0000
  -1.0000   1.0000
  -1.0000  -1.0000
   -.1000    .1000
   -.1000   -.1000
