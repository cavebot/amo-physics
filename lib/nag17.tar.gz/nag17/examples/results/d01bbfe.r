 D01BBF Example Program Results
 
 Laguerre formula,  6 points
 
     Abscissae        Weights
 
     .222847D+00    .573536D+00
     .118893D+01    .136925D+01
     .299274D+01    .226068D+01
     .577514D+01    .335052D+01
     .983747D+01    .488683D+01
     .159829D+02    .784902D+01
