 F04AYF Example Program Results
 
  Solution
   -1.0000
    3.0000
    1.0000
    2.0000
