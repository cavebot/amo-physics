 F02WUF Example Program Results
 
 Singular value decomposition of A
 
 Singular values
   6.5616   3.0000   2.4384
 
 Left-hand singular vectors, by column
   -.7699    .5883   -.2471
   -.4324   -.1961    .8801
   -.4694   -.7845   -.4054
 
 Right-hand singular vectors, by column
    .4694   -.7845    .4054
    .4324   -.1961   -.8801
    .7699    .5883    .2471
 
 Vector Q'*B
   1.6716    .3922   -.2276
