 G02BAF Example Program Results
 
 Number of variables (columns) = 3
 Number of cases     (rows)    = 5
 
 Data matrix is:-
 
            1           2           3
   1      2.0000      3.0000      3.0000
   2      4.0000      6.0000      4.0000
   3      9.0000      9.0000       .0000
   4       .0000     12.0000      2.0000
   5     12.0000     -1.0000      5.0000
 
 Variable   Mean    St. dev.
     1     5.4000     4.9800
     2     5.8000     5.0695
     3     2.8000     1.9235
 
 Sums of squares and cross-products of deviations
            1           2           3
   1     99.2000    -57.6000      6.4000
   2    -57.6000    102.8000    -29.2000
   3      6.4000    -29.2000     14.8000
 
 Correlation coefficients
            1           2           3
   1      1.0000      -.5704       .1670
   2      -.5704      1.0000      -.7486
   3       .1670      -.7486      1.0000
