 C02AFF Example Program Results
 
 Degree of polynomial =    5
 
 Roots of polynomial
 
 z =  -2.4328D+01   -4.8555D+00*i
 z =   5.2487D+00   +2.2736D+01*i
 z =   1.4653D+01   -1.6569D+01*i
 z =  -6.9264D-03   -7.4434D-03*i
 z =   6.5264D-03   +7.4232D-03*i
