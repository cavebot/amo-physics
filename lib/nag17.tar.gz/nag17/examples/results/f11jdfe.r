 F11JDF Example Program Results
 Converged in         6 iterations
 Final residual norm =       5.329D-15
       1.0000D+00
       2.0000D+00
       3.0000D+00
       4.0000D+00
       5.0000D+00
       6.0000D+00
       7.0000D+00
