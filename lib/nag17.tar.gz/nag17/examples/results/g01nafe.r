 G01NAF Example Program Results
 
 N =  10 BETA =   .800 CON =  1.000
 
     Cumulants       Moments
 
  1   .1752D+02       .1752D+02
  2   .3501D+03       .6569D+03
  3   .1609D+05       .3986D+05
  4   .1170D+07       .3404D+07
