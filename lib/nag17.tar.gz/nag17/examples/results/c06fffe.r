 C06FFF Example Program Results
 
 Original data
 
 Real      1.000      .999      .987      .936      .802
 Imag       .000     -.040     -.159     -.352     -.597
 
 Real       .994      .989      .963      .891      .731
 Imag      -.111     -.151     -.268     -.454     -.682
 
 Real       .903      .885      .823      .694      .467
 Imag      -.430     -.466     -.568     -.720     -.884
 
 Discrete Fourier transform of variable 2
 
 Real      2.113      .288      .126     -.003     -.287
 Imag      -.513      .000      .130      .190      .194
 
 Real      2.043      .286      .139      .018     -.263
 Imag      -.745     -.032      .115      .189      .225
 
 Real      1.687      .260      .170      .079     -.176
 Imag     -1.372     -.125      .063      .173      .299
 
 Original sequence as restored by inverse transform
 
 Real      1.000      .999      .987      .936      .802
 Imag       .000     -.040     -.159     -.352     -.597
 
 Real       .994      .989      .963      .891      .731
 Imag      -.111     -.151     -.268     -.454     -.682
 
 Real       .903      .885      .823      .694      .467
 Imag      -.430     -.466     -.568     -.720     -.884
