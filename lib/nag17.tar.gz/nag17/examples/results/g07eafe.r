 G07EAF Example Program Results
 
  Location estimator     Confidence Interval 
 
       -.1300            ( -.3300 ,  .0350 )
 
  Corresponding Wilcoxon statistics
 
 Lower :   556.00
 Upper :   264.00
