 F04ZCF Example Program Results
 
 Computed norm of A = 23.4875
 Estimated norm of inverse(A) = 37.0391
 Estimated condition number of A = 870.0
