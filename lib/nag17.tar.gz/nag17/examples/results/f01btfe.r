 F01BTF Example Program Results
 
 Decomposition as stored in array A
    3.0000  -2.0000   4.0000   1.0000
   -1.0000  -7.0000  -3.1429   -.7143
    4.0000  -5.0000  -1.7143   3.2500
    2.0000   2.0000    .2857    .5000
 
 Pivotal rows
    1.   4.   3.   4.
