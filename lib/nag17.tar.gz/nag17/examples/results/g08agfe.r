 G08AGF Example Program Results
 
 Wilcoxon one sample signed ranks test
 
 Data values
     82.0 69.0 73.0 43.0 58.0 56.0 76.0 65.0
     63.0 42.0 74.0 37.0 51.0 43.0 80.0 62.0
 
 Test statistic            =  32.0000
 Normalized test statistic =   1.8904
 Degrees of freedom        =        8
 Two tail probability      =    .0547
