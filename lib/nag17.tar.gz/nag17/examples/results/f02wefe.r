 F02WEF Example Program Results
 
 
 Example 1
 
 Singular value decomposition of A
 
 Singular values
   6.5616   3.0000   2.4384
 
 Left-hand singular vectors, by column
    .6011   -.1961   -.3165
    .6011   -.1961   -.3165
    .4166    .1569    .6941
    .1688   -.3922    .5636
   -.2742   -.8629    .0139
 
 Right-hand singular vectors, by column
    .4694   -.7845    .4054
    .4324   -.1961   -.8801
    .7699    .5883    .2471
 
 Vector Q'*B
   1.6716    .3922   -.2276   -.1000   -.1000
 
 
 Example 2
 
 Singular value decomposition of A
 
 Singular values
   6.5616   3.0000   2.4384
 
 Left-hand singular vectors, by column
   -.4694    .7845   -.4054
   -.4324    .1961    .8801
   -.7699   -.5883   -.2471
 
 Right-hand singular vectors, by column
   -.6011    .1961    .3165
   -.6011    .1961    .3165
   -.4166   -.1569   -.6941
   -.1688    .3922   -.5636
    .2742    .8629   -.0139
