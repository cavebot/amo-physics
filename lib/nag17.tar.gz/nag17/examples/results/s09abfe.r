 S09ABF Example Program Results
 
      X           Y        IFAIL
 
   -5.000D-01   2.094D+00      0
    1.000D-01   1.471D+00      0
    9.000D-01   4.510D-01      0
    2.000D+00   0.000D+00      1
   -1.500D+00   0.000D+00      1
