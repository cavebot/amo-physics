 G02HDF Example Program Results
 
 G02HDF required    5 iterations to converge
                    K =    3
                Sigma =    2.7783
     THETA
   12.2321
    1.0500
    1.2464
 
   Weights  Residuals
     .4039    .5643
     .5012  -1.1286
     .4039    .5643
     .5012  -1.1286
     .3862   1.1286
