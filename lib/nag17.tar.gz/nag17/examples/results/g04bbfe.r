 G04BBF Example Program Results
 
  ANOVA table
 
   Source        df         SS          MS          F        Prob
 
 Blocks          9.       60.00        6.67        4.79      .0039
 Treatments      5.      101.78       20.36       14.62      .0000
 Residual       15.       20.89        1.39
 Total          29.      182.67
 
  Efficiency Factors
 
       .00       .80       .80       .80       .80       .80
 
  Grand Mean      5.33
 
  Treatment Means
 
      2.50      7.25      8.08      5.92      2.92      5.33
 
  Standard errors of differences between means
 
       .83
       .83       .83
       .83       .83       .83
       .83       .83       .83       .83
       .83       .83       .83       .83       .83
