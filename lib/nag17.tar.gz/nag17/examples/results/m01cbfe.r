 M01CBF Example Program Results
 
 Sorted numbers
 
     999    112     99     96     90     78     78     69     69     67
      45     45     45     24     23      1
