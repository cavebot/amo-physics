 F07HDF Example Program Results
 
 Factor
             1          2          3          4
 1      2.3431
 2      1.1438     2.0789
 3                -1.1497     1.1306
 4                           -1.9635     1.1465
