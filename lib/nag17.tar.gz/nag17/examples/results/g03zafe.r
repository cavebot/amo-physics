 G03ZAF Example Program Results
 
  Standardized Values
     .100   1.071
   -1.100   -.119
    1.300    .357
    -.300  -1.309
