 F01AXF Example Program Results
 
 ALPHA
   -1.9105    .1484
 
 Array QR
    3.0105  -1.6697
    1.2000   -.1727
    1.0000    .1464
 
 IPIV
     1    2
