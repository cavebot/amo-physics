 F07BDF Example Program Results
 
 Details of factorization
             1          2          3          4
 1     -6.9800     2.4600    -2.7300    -2.1300
 2       .0330     2.5600     2.4600     4.0700
 3                  .9605    -5.9329    -3.8391
 4                             .8057     -.7269
 
 IPIV
             2          3          3          4
