 F08GGF Example Program Results
 
 Eigenvalues
    -5.0034 -1.9987
 
 Eigenvectors
          1       2
 1    .5658  -.2328
 2   -.3478   .7994
 3   -.4740  -.4087
 4    .5781   .3737
