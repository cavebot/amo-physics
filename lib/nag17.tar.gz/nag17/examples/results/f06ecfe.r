 F06ECF Example Program Results


 Test of subprogram number  1            F06EAF
                                    ----- PASS -----

 Test of subprogram number  2            F06ECF
                                    ----- PASS -----

 Test of subprogram number  3            F06AAF
                                    ----- PASS -----

 Test of subprogram number  4            F06EPF
                                    ----- PASS -----

 Test of subprogram number  5            F06EFF
                                    ----- PASS -----

 Test of subprogram number  6            F06EGF
                                    ----- PASS -----

 Test of subprogram number  7            F06EJF
                                    ----- PASS -----

 Test of subprogram number  8            F06EKF
                                    ----- PASS -----

 Test of subprogram number  9            F06EDF
                                    ----- PASS -----

 Test of subprogram number 10            F06JLF
                                    ----- PASS -----
