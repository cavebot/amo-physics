 G08AEF Example Program Results
 
 Friedman test
 
 Data values
 
    Group Group Group
      1     2     3
     1.0   3.0   2.0
     2.0   3.0   1.0
     1.0   3.0   2.0
     1.0   2.0   3.0
     3.0   1.0   2.0
     2.0   3.0   1.0
     3.0   2.0   1.0
     1.0   3.0   2.0
     3.0   1.0   2.0
     3.0   1.0   2.0
     2.0   3.0   1.0
     2.0   3.0   1.0
     3.0   2.0   1.0
     2.0   3.0   1.0
     2.5   2.5   1.0
     3.0   2.0   1.0
     3.0   2.0   1.0
     2.0   3.0   1.0
 
 Test statistic        8.583
 Degrees of freedom        2
 Significance           .014
