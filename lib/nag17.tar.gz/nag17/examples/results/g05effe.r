 G05EFF Example Program Results
 
     7
     3
     4
     3
     7
