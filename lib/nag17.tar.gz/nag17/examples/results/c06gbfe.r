 C06GBF Example Program Results
 
 Components of inverse discrete Fourier transform
 
            Real      Imag
 
      0   2.48361    .00000
      1   -.26599   -.53090
      2   -.25768   -.20298
      3   -.25636   -.05806
      4   -.25636    .05806
      5   -.25768    .20298
      6   -.26599    .53090
