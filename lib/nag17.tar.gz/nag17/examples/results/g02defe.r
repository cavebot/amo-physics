 G02DEF Example Program Results
 
 Variable   1 added
 Residual sum of squares =     .4016D+01
 Degrees of freedom =   10
 
 Variable   Parameter estimate   Standard error
 
      1           .4410D+01           .4376D+00
      2           .9498D+00           .1060D+00
 
 Variable   3 added
 Residual sum of squares =     .3887D+01
 Degrees of freedom =    9
 
 Variable   Parameter estimate   Standard error
 
      1           .4224D+01           .5673D+00
      2           .1055D+01           .2222D+00
      3          -.4196D+00           .7670D+00
 
 Variable   4 added
 Residual sum of squares =     .1870D+00
 Degrees of freedom =    8
 
 Variable   Parameter estimate   Standard error
 
      1           .2760D+01           .1759D+00
      2           .1706D+01           .7310D-01
      3           .4458D+01           .4268D+00
      4          -.1301D+01           .1034D+00
 
 Variable   2 added
 Residual sum of squares =     .8407D-01
 Degrees of freedom =    7
 
 Variable   Parameter estimate   Standard error
 
      1           .3144D+01           .1818D+00
      2           .9075D+00           .2776D+00
      3           .2079D+01           .8680D+00
      4          -.6159D+00           .2453D+00
      5           .2922D+00           .9981D-01
