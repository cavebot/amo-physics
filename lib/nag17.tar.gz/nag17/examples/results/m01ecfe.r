 M01ECF Example Program Results
 
 Names in order of frequency
 
 C05AZF
 C05ADF
 C02AEF
 A02ACF
 A02ABF
 A02AAF
 C05AGF
 C05AVF
 C05AXF
 C02ADF
 C05AJF
