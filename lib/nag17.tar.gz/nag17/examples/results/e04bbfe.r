 E04BBF Example Program Results
 
 The minimum lies in the interval 4.49340946 to 4.49340952
 Its estimated position is 4.49340946,
 where the function value is  -.2172
 and the gradient is-3.8D-16 (machine dependent)
  6 calls of FUNCT were required
