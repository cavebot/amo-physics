 F01BVF Example Program Results
 
 Selected eigenvalues
    -.2643   -.1530   -.0418
