 G01EBF Example Program Results
 
    T      DF     PROB  TAIL
 
   .850  20.000   .7973  L
   .850  20.000   .4054  S
   .850  20.000   .5946  C
   .850  20.000   .2027  U
