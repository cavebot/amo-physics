 G05DCF Example Program Results
 
     3.0341
     -.8490
      .2099
     -.8548
     3.9709
