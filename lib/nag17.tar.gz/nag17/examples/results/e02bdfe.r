 E02BDF Example Program Results
 
 Definite integral =    .100D+03
