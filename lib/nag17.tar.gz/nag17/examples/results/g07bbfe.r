 G07BBF Example Program Results
 
  Mean =   4.4924
  Standard deviation =   1.0196
  Standard error of mean =    .2606
  Standard error of sigma =    .1940
  Correlation coefficient =    .0160
  Number of right censored observations =  3
  Number of left censored observations =  2
  Number of interval censored observations =  1
  Number of exactly specified observations = 12
  Number of iterations =  5
  Log-likelihood = -22.2817
