 F07VUF Example Program Results
 
 Estimate of condition number =  3.35D+01
