 E02BEF Example Program Results
 
 Calling with smoothing factor S =   1.000D+00
 
                                        B-Spline
              J       Knot K(J+2)   Coefficient C(J)
              1                         -1.3201
              2           .0000          1.3542
              3          4.0000          5.5510
              4          8.0000          4.7031
              5                          8.2277
 
 Weighted sum of squared residuals FP =   1.000D+00
 
 
 Calling with smoothing factor S =   5.000D-01
 
                                        B-Spline
              J       Knot K(J+2)   Coefficient C(J)
              1                         -1.1072
              2           .0000          -.6571
              3          1.0000           .4350
              4          2.0000          2.8061
              5          4.0000          4.6824
              6          5.0000          4.6416
              7          6.0000          5.1976
              8          8.0000          6.9008
              9                          7.9979
 
 Weighted sum of squared residuals FP =   5.001D-01
 
 
 Calling with smoothing factor S =   1.000D-01
 
                                        B-Spline
              J       Knot K(J+2)   Coefficient C(J)
              1                         -1.0900
              2           .0000          -.6422
              3          1.0000           .0369
              4          1.5000          1.6353
              5          2.0000          2.1274
              6          3.0000          4.5526
              7          4.0000          4.2225
              8          4.5000          4.9108
              9          5.0000          4.4159
             10          6.0000          5.4794
             11          8.0000          6.8308
             12                          7.9935
 
 Weighted sum of squared residuals FP =   1.000D-01
 
