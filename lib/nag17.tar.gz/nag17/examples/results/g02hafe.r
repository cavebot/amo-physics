 G02HAF Example Program Results
 
 Sigma =      .2026
 
        THETA      Standard
                    errors
       4.0423        .0384
       1.3083        .0272
        .7519        .0311
 
      Weights     Residuals
        .5783        .1179
        .5783        .1141
        .5783       -.0987
        .5783       -.0026
        .4603       -.1256
        .4603       -.6385
        .4603        .0410
        .4603       -.0462
