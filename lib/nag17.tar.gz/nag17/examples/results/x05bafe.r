 X05BAF Example Program Results
 It took  1.00D-02 seconds to compute e =  2.71828D+00
