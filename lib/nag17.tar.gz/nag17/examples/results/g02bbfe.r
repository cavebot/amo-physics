 G02BBF Example Program Results
 
 Number of variables (columns) = 3
 Number of cases     (rows)    = 5
 
 Data matrix is:-
 
            1           2           3
   1      2.0000      3.0000      3.0000
   2      4.0000      6.0000      4.0000
   3      9.0000      9.0000       .0000
   4       .0000     12.0000      2.0000
   5     12.0000     -1.0000      5.0000
 
 Variable   Mean    St. dev.
     1     6.0000     5.2915
     2     2.6667     3.5119
     3     4.0000     1.0000
 
 Sums of squares and cross-products of deviations
            1           2           3
   1     56.0000    -30.0000     10.0000
   2    -30.0000     24.6667     -4.0000
   3     10.0000     -4.0000      2.0000
 
 Correlation coefficients
            1           2           3
   1      1.0000      -.8072       .9449
   2      -.8072      1.0000      -.5695
   3       .9449      -.5695      1.0000
 
 Number of cases actually used:  3
