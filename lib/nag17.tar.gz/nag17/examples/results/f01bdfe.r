 F01BDF Example Program Results
 
 Lower triangle of Q
 1233.7000
  830.4000 326.8000
  588.9000 198.8000 114.1000
   52.7000 -31.6000 -31.7000 -17.1000
 
 Strict lower triangle of L
    3.0000
    4.0000   2.0000
    1.0000   4.0000   3.0000
 
 Diagonal of L
    1.0000   2.0000   2.0000   1.0000
