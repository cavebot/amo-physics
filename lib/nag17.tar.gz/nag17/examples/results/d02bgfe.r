 D02BGF Example Program Results
 
 Calculation with TOL =  .1D-03
  Y(M) changes sign at X =  7.2884
 
 Calculation with TOL =  .1D-04
  Y(M) changes sign at X =  7.2883
