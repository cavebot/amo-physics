 F06HBF Example Program Results

  Testing routine   F06HBF
                ---- PASS ----
 
  Testing routine   F06KFF
                ---- PASS ----
 
  Testing routine   F06KJF
                ---- PASS ----
 
  Testing routine   F06HPF
                ---- PASS ----
 
  Testing routine   F06KPF
                ---- PASS ----
 
  Testing routine   F06HCF
                ---- PASS ----
 
  Testing routine   F06KCF
                ---- PASS ----
 
  Testing routine   F06HGF
                ---- PASS ----
 
  Testing routine   F06KDF
                ---- PASS ----
 
  Testing routine   F06HDF
                ---- PASS ----
 
  Testing routine   F06HTF
                ---- PASS ----
 
  Testing routine   F06HRF
                ---- PASS ----
 
  Testing routine   F06HQF
                ---- PASS ----
 
