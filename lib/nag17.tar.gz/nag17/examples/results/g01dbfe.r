 G01DBF Example Program Results
 
 Sample size = 10
 Normal scores
               -1.5388     -1.0014      -.6561      -.3757      -.1227
                 .1227       .3757       .6561      1.0014      1.5388
