 G01ECF Example Program Results
 
    X       DF    PROB
 
  8.260  20.000   .0100
  6.200   7.500   .4279
 55.760  45.000   .8694
