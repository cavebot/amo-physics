 F02SXF Example Program Results
 
 Matrix  P
   1.0000    .0000    .0000
    .0000    .5547   -.8321
    .0000    .8321    .5547
