 S10ACF Example Program Results
 
      X           Y        IFAIL
 
   -1.000D+01   1.101D+04      0
   -5.000D-01   1.128D+00      0
    0.000D+00   1.000D+00      0
    5.000D-01   1.128D+00      0
    2.500D+01   3.600D+10      0
