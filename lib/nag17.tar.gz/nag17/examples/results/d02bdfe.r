 D02BDF Example Program Results
 
 Simple stiff problem
 
  Calculation with TOL =   .1D-05
 
   X and solution       .13451       .99476       .00004       .00520
   Current error estimates     .45D-06     .13D-05    -.17D-05
   Maximum error estimates     .47D-06     .13D-05    -.17D-05
   Number of sign changes for each estimate   3.  73.  53.
   Stiffness factor     1.0000
 
   X and solution       .27004       .98975       .00003       .01022
   Current error estimates     .19D-05    -.30D-06    -.16D-05
   Maximum error estimates     .19D-05     .13D-05    -.30D-05
   Number of sign changes for each estimate   3. 148.  53.
   Stiffness factor     1.0000
 
   X and solution       .30000       .98867       .00003       .01129
   Current error estimates     .23D-05    -.17D-07    -.22D-05
   Maximum error estimates     .23D-05     .13D-05    -.34D-05
   Number of sign changes for each estimate   3. 164.  53.
   Stiffness factor      .9076
 
 
 Projectile problem
 
  Calculation with TOL =   .1D-03
 
   X and solution      2.61819      1.20368       .38798       .18054
   Current error estimates     .88D-04    -.49D-05    -.11D-04
   Maximum error estimates     .88D-04    -.49D-05    -.11D-04
   Number of sign changes for each estimate  -1.  -1.  -1.
   Stiffness factor      .0000
 
   X and solution      4.93904      1.01683       .38600      -.33836
   Current error estimates     .50D-04    -.22D-06    -.26D-04
   Maximum error estimates     .88D-04    -.49D-05    -.26D-04
   Number of sign changes for each estimate   0.   0.  -1.
   Stiffness factor      .0000
 
   X and solution      6.94621      -.19042       .45792      -.70972
   Current error estimates    -.85D-04     .75D-05    -.27D-04
   Maximum error estimates     .88D-04     .75D-05    -.27D-04
   Number of sign changes for each estimate   1.   1.  -1.
   Stiffness factor      .0000
 
   X and solution      8.00000     -1.24579       .51298      -.85369
   Current error estimates    -.14D-03     .91D-05    -.22D-04
   Maximum error estimates    -.14D-03     .91D-05    -.27D-04
   Number of sign changes for each estimate   1.   1.   0.
   Stiffness factor      .0000
