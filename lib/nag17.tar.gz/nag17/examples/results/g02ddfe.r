 G02DDF Example Program Results
 
 Residual sum of squares =    .2223D+02
 Degrees of freedom =    8
 
 Variable   Parameter estimate   Standard error
 
      1           .3600D+02           .9623D+00
      2           .3730D+02           .9623D+00
      3           .4160D+02           .9623D+00
      4           .3788D+02           .9623D+00
