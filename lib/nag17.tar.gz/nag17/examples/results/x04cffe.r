 X04CFF Example Program Results
 
 Example 1:
             1          2          3          4          5
 1     21.0000    12.0000
 2     31.0000    22.0000    13.0000
 3                32.0000    23.0000    14.0000
 4                           33.0000    24.0000    15.0000
 5                                      34.0000    25.0000
 
 Example 2:
               Un    Deux   Trois  Quatre    Cinq
     Uno    31.00   22.00   13.00
     Duo    41.00   32.00   23.00   14.00
     Tre            42.00   33.00   24.00   15.00
 Quattro                    43.00   34.00   25.00
  Cinque                            44.00   35.00
