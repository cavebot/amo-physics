 F08SEF Example Program Results
 
 Eigenvalues
    -2.2254  -.4548   .1001  1.1270
