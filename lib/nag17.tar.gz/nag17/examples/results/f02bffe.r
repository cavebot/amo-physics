 F02BFF Example Program Results
 
 Eigenvalues
   -1.0000   2.0000   4.0000
 
 No. of bisections =   155 (machine dependent)
 
 Error bound =   .4205D-14 (machine dependent)
