 G02BWF Example Program Results
 
 Correlation matrix
          1       2       3
 1   1.0000   .9908   .9903
 2           1.0000   .9624
 3                   1.0000
