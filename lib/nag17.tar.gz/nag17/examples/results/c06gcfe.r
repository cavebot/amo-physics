 C06GCF Example Program Results
 
 Components of inverse discrete Fourier transform
 
            Real      Imag
 
      0   2.48361   -.47100
      1    .01983   -.56496
      2   -.14825   -.30840
      3   -.22506   -.17477
      4   -.28767   -.05865
      5   -.36711    .09756
      6   -.55180    .49684
