 F01BEF Example Program Results
 
 Eigenvalues
  -274.056    -.017     .678 1930.895
 
 Eigenvectors
     -.544     .128     .079    -.825
     -.464     .152   -1.069   -3.409
      .086    -.102     .511   -4.870
     3.685     .055    -.225   -3.656
