 G05DRF Example Program Results
 
          1
          3
         14
         51
        121
