 D01DAF Example Program Results
 
 First formulation
 Integral =    .6667
 Number of function evaluations =  189
 
 Second formulation
 Integral =    .6667
 Number of function evaluations =   89
