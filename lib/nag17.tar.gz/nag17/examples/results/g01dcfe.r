 G01DCF Example Program Results
 
 Sample size =  6
 Variance-covariance matrix
    .4159
    .2085   .2796
    .1394   .1889   .2462
    .1025   .1397   .1834   .2462
    .0774   .1060   .1397   .1889   .2796
    .0563   .0774   .1025   .1394   .2085   .4159
