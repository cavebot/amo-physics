 F06QTF Example Program Results

 F06QTF Example Program ends OK
