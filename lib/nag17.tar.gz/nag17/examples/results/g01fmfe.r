 G01FMF Example Program Results
 
   P     V    IR    Quantile 
 
   .95  10.0   5     4.6543
   .30  60.0  12     2.8099
   .90   5.0   4     4.2636
