 G02HFF Example Program Results
 
 Covariance matrix
      .2070     .0000    -.0478
      .0000     .2229     .0000
     -.0478     .0000     .0796
