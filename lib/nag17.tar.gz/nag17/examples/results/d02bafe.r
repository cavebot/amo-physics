 D02BAF Example Program Results
 
 Calculation with TOL =  .1D-03
     X         Y(1)         Y(2)         Y(3)
     .00       .00000       .50000       .62832
    8.00     -1.24582       .51298      -.85370
 
 Calculation with TOL =  .1D-04
     X         Y(1)         Y(2)         Y(3)
     .00       .00000       .50000       .62832
    8.00     -1.24593       .51299      -.85371
