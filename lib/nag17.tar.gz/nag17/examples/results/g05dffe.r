 G05DFF Example Program Results
 
     4.9225
     -.7160
    24.9342
    -1.2143
     1.6063
