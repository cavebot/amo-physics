 D03PCF Example Program Results


 Accuracy requirement  =   .10000D-03
 Parameter ALPHA =           .100D+01

   T  /  X     .0000   .4000   .6000   .8000   .9000  1.0000

  .0001 U(1)   .0000   .8008  1.1988  1.5990  1.7958  1.8483
        U(2)   .9997   .9995   .9994   .9988   .9664   .0000

  .0010 U(1)   .0000   .7982  1.1940  1.5841  1.7179  1.6735
        U(2)   .9969   .9952   .9937   .9483   .6390   .0000

  .0100 U(1)   .0000   .7676  1.1238  1.3548  1.3639  1.2834
        U(2)   .9627   .9495   .8752   .5545   .2914   .0000

  .1000 U(1)   .0000   .3910   .5011   .5303   .5126   .4749
        U(2)   .5469   .4303   .2999   .1482   .0726   .0000

 1.0000 U(1)   .0000   .0005   .0006   .0006   .0006   .0005
        U(2)   .0007   .0005   .0003   .0001   .0001   .0000

 Number of integration steps in time                   136
 Number of residual evaluations of resulting ODE system 585
 Number of Jacobian evaluations                          36
 Number of iterations of nonlinear solver               316

