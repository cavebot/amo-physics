 G02CBF Example Program Results
 
  Case     Independent     Dependent
 number     variable       variable
 
    1         1.0000        20.0000
    2          .0000        15.5000
    3         4.0000        28.3000
    4         7.5000        45.0000
    5         2.5000        24.5000
    6          .0000        10.0000
    7        10.0000        99.0000
    8         5.0000        31.2000
 
 Mean of independent variable               =   3.7500
 Mean of   dependent variable               =  34.1875
 Standard deviation of independent variable =   3.6253
 Standard deviation of   dependent variable =  28.2604
 Correlation coefficient                    =    .9096
 
 Regression coefficient                     =   8.2051
 Standard error of coefficient              =    .9052
 t-value for coefficient                    =   9.0642
 
 Analysis of regression table :-
 
       Source        Sum of squares  D.F.    Mean square     F-value
 
 Due to regression    13767.8054      1.    13767.8054       82.1591
 About  regression     1173.0246      7.      167.5749
 Total                14940.8300      8.
