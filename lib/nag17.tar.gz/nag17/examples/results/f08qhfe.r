 F08QHF Example Program Results
 
 Solution matrix X
          1       2       3       4
 1   -.4209   .1764   .2438  -.9577
 2    .5600  -.8337  -.7221   .5386
 3   -.1246  -.3392   .6221   .8691
 4   -.2865   .4113   .5535   .3174
 
 SCALE =   1.00D+00
