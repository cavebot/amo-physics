 G02DFF Example Program Results
 
 Results from full model
 Residual sum of squares =     .8407D-01
 Degrees of freedom =    7
 
 Variable   2 dropped
 Residual sum of squares =     .2124D+00
 Degrees of freedom =    8
 
 Parameter estimate   Standard error
 
       .3637D+01           .1508D+00
       .6126D+00           .2801D-01
      -.6015D+00           .4234D+00
       .1671D+00           .7866D-01
 Variable   4 dropped
 Residual sum of squares =     .3322D+00
 Degrees of freedom =    9
 
 Parameter estimate   Standard error
 
       .3597D+01           .1765D+00
       .6209D+00           .3271D-01
       .2425D+00           .1724D+00
