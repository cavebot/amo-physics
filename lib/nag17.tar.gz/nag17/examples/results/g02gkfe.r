 G02GKF Example Program Results
 
 Deviance =    .9038D+01
 Degrees of freedom =  8
 
       Estimate     Standard error
 
         3.9831         .0396
          .3961         .0458
          .4118         .0457
         -.8079         .0622
          .5112         .0562
         -.2285         .0727
          .4680         .0569
         -.0316         .0675
         -.7191         .0887
