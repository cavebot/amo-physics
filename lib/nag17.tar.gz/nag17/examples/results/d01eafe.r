 D01EAF Example Program Results
 ** MAXCLS too small to obtain required accuracy
 ** ABNORMAL EXIT from NAG Library routine D01EAF: IFAIL =     1
 ** NAG soft failure - control returned
 
 Results so far (     57 FUNSUB calls in last call of D01EAF)
 
    I       Integral   Estimated error
    1         .0422         .0086
    2         .3998         .0038
    3         .3898         .0127
    4         .0214         .0099
    5        -.3666         .0020
    6        -.4176         .0120
    7        -.0846         .0110
    8         .3261         .0001
    9         .4371         .0112
   10         .1461         .0119
 
 ** MAXCLS too small to obtain required accuracy
 ** ABNORMAL EXIT from NAG Library routine D01EAF: IFAIL =     1
 ** NAG soft failure - control returned
 
 Results so far (    798 FUNSUB calls in last call of D01EAF)
 
    I       Integral   Estimated error
    1         .0384         .0006
    2         .4012         .0006
    3         .3952         .0006
    4         .0258         .0006
    5        -.3673         .0006
    6        -.4227         .0006
    7        -.0895         .0006
    8         .3260         .0006
    9         .4417         .0006
   10         .1514         .0006
 
 
 Final results (    912 FUNSUB calls in last call of D01EAF)
 
    I       Integral   Estimated error
    1         .0384         .0004
    2         .4012         .0003
    3         .3952         .0003
    4         .0258         .0003
    5        -.3672         .0003
    6        -.4227         .0003
    7        -.0895         .0003
    8         .3260         .0003
    9         .4417         .0003
   10         .1514         .0003
