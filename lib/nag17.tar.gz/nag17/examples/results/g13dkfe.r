 G13DKF Example Program Results
 
  FORECAST SUMMARY TABLE
  ----------------------
 
  Forecast origin is set at t =   48
 
 Lead Time                      1         2         3         4         5
 
 Series  1 : Forecast          7.82      7.28      6.77      6.33      5.95
           : Standard Error    1.72      2.23      2.51      2.68      2.79
 Series  2 : Forecast         10.31      9.25      8.65      8.30      8.10
           : Standard Error    2.32      2.68      2.78      2.82      2.83
 
 
  FORECAST SUMMARY TABLE
  ----------------------
 
  Forecast origin is set at t =   49
 
 Lead Time                      1         2         3         4         5
 
 Series  1 : Forecast          8.10      7.49      6.94      6.46      6.06
           : Standard Error     .00      1.72      2.23      2.51      2.68
 Series  2 : Forecast         10.20      9.19      8.61      8.28      8.08
           : Standard Error     .00      2.32      2.68      2.78      2.82
 
 
  FORECAST SUMMARY TABLE
  ----------------------
 
  Forecast origin is set at t =   50
 
 Lead Time                      1         2         3         4         5
 
 Series  1 : Forecast          8.10      8.50      7.80      7.18      6.65
           : Standard Error     .00       .00      1.72      2.23      2.51
 Series  2 : Forecast         10.20     10.00      9.08      8.54      8.24
           : Standard Error     .00       .00      2.32      2.68      2.78
 
