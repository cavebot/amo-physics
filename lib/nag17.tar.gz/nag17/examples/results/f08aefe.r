 F08AEF Example Program Results
 
 Least-squares solution(s)
             1          2
 1      1.5146    -1.5838
 2      1.8621      .5536
 3     -1.4467     1.3491
 4       .0396     2.9600
