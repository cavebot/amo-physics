 G01ALF Example Program Results
 
 Maximum              12.0000
 Upper Hinge           9.5000
 Median                6.5000
 Lower Hinge           2.5000
 Minimum               1.0000
