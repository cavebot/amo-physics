 F01QCF Example Program Results
 
 QR factorization of A
 
 Vector ZETA
   1.2247   1.1547   1.2649
 
 Matrix A after factorization (upper triangular part is R)
  -4.0000  -2.0000  -3.0000
    .4082  -3.0000  -2.0000
    .3266   -.4619  -4.0000
    .4082   -.5774    .0000
    .2449   -.3464   -.6325
