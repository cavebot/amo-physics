 G08AAF Example Program Results
 
 Sign test
 
 Data values
 
     4. 4. 5. 5. 3. 2. 5. 3. 1. 5. 5. 5. 4. 5. 5. 5. 5.
     2. 3. 3. 3. 3. 3. 3. 3. 2. 3. 2. 2. 5. 2. 5. 3. 1.
 
 Test statistic       3
 Observations        14
 Lower tail prob.  .029
