 G13BHF Example Program Results
 
 The forecast values and their standard errors
 
    I     FVA       FSD
 
    1   88.2723    4.7881
    2   99.9425    6.4690
    3  100.6499    7.3175
    4   95.0958    7.5534
 
 The values of z(t) and n(t)
    1  164.4620  -76.1897
    2  170.3924  -70.4499
    3  174.5193  -73.8694
    4  175.2747  -80.1789
