 D02NCF Example Program Results
 
     X          Y(1)           Y(2)           Y(3)
     .000      1.00000         .00000         .00000
    5.000       .89152         .00002         .10846
   10.000       .84137         .00002         .15861
 
  HUSED =   .11280D+01  HNEXT =   .11280D+01  TCUR =   .10034D+02
  NST =     63    NRE =    274    NJE =     14
  NQU =      4    NQ  =      4  NITER =    272
  Max Err Comp =    3
 
