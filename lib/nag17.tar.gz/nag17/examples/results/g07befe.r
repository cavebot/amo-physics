 G07BEF Example Program Results
 
  BETA  =    -2.1073 Standard error =      .4627
  GAMMA =     2.7870 Standard error =      .4273
