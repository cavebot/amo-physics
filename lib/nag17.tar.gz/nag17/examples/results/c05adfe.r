 C05ADF Example Program Results
 
 Zero =      .56714
