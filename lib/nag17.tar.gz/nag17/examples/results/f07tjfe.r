 F07TJF Example Program Results
 
 Inverse
             1          2          3          4
 1       .2326
 2      -.1891     -.2053
 3       .0043     -.0079     -.1247
 4       .8463     -.2738    -6.1825     8.3333
