 F07VGF Example Program Results
 
 Estimate of condition number =  6.96D+01
