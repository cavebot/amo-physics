 F06QQF Example Program Results

 F06QQF Example Program ends OK
