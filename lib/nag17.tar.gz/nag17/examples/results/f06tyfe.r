 F06TYF Example Program Results

 F06TYF Example Program ends OK
