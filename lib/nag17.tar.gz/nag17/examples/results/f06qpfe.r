 F06QPF Example Program Results

 F06QPF Example Program ends OK
