 C06FUF Example Program Results
 
 Original data values
 
 Real      1.000      .999      .987      .936      .802
 Imag       .000     -.040     -.159     -.352     -.597
 
 Real       .994      .989      .963      .891      .731
 Imag      -.111     -.151     -.268     -.454     -.682
 
 Real       .903      .885      .823      .694      .467
 Imag      -.430     -.466     -.568     -.720     -.884
 
 Components of discrete Fourier transform
 
 Real      3.373      .481      .251      .054     -.419
 Imag     -1.519     -.091      .178      .319      .415
 
 Real       .457      .055      .009     -.022     -.076
 Imag       .137      .032      .039      .036      .004
 
 Real      -.170     -.037     -.042     -.038     -.002
 Imag       .493      .058      .008     -.025     -.083
 
 Original sequence as restored by inverse transform
 
 Real      1.000      .999      .987      .936      .802
 Imag       .000     -.040     -.159     -.352     -.597
 
 Real       .994      .989      .963      .891      .731
 Imag      -.111     -.151     -.268     -.454     -.682
 
 Real       .903      .885      .823      .694      .467
 Imag      -.430     -.466     -.568     -.720     -.884
