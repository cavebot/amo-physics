 F07FHF Example Program Results
 
 Solution(s)
             1          2
 1      1.0000     4.0000
 2     -1.0000     3.0000
 3      2.0000     2.0000
 4     -3.0000     1.0000
 
 Backward errors (machine-dependent)
       8.1D-17    5.0D-17
 Estimated forward error bounds (machine-dependent)
       2.4D-14    2.3D-14
