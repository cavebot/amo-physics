  G11AAF Example Program Results
 
 Probability =  .0975
 Pearson Chi-square statistic =    7.844
 Likelihood ratio test statistic =    8.096
 Degrees of freedom =   4.
