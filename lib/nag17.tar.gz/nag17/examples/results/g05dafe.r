 G05DAF Example Program Results
 
     1.3976
     1.1129
     1.1856
     1.1125
     1.4394
