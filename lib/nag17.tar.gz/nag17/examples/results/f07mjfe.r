 F07MJF Example Program Results
 
 Inverse
             1          2          3          4
 1       .7485
 2       .5221     -.1605
 3     -1.0058     -.3131     1.3501
 4     -1.4386     -.7440     2.0667     2.4547
