 S21BBF Example Program Results
 
     X      Y      Z        S21BBF  IFAIL
 
     .50   1.00   1.50      1.0281    0
    1.00   1.50   2.00       .8260    0
    1.50   2.00   2.50       .7116    0
