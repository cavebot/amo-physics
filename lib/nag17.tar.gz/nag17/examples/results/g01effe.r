 G01EFF Example Program Results
 
 Gamma deviate    Alpha     Beta    Lower tail prob.
 
     15.50         4.00     2.00         .9499
       .50         4.00     1.00         .0018
     10.00         1.00     2.00         .9933
      5.00         2.00     2.00         .7127
