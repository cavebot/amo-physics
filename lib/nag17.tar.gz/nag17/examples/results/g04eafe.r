 G04EAF Example Program Results
 
 Model not of full rank, rank =    4
 
 Residual sum of squares =    .2223D+02
 Degrees of freedom =    8
 
 Variable   Parameter estimate   Standard error
 
      1           .3056D+02           .3849D+00
      2           .5447D+01           .8390D+00
      3           .6743D+01           .8390D+00
      4           .1105D+02           .8390D+00
      5           .7320D+01           .8390D+00
