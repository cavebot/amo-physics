 G05CAF Example Program Results
 
      .7951
      .2257
      .3713
      .2250
      .8787
