 E02AHF Example Program Results
 
    I  Argument    1st deriv    2nd deriv
    1   -.5000        .2453        .1637
    2    .5000        .4777        .3185
    3   1.5000        .9304        .6203
    4   2.5000       1.8119       1.2056
