 G05EEF Example Program Results
 
    58
    42
    46
    42
    62
