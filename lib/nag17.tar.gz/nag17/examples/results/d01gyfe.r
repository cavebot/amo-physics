 D01GYF Example Program Results
 
 NDIM =  4 NPTS =   631
 
 Coefficients =    1.  198.   82.  461.
