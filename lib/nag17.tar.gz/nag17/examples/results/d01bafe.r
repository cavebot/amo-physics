 D01BAF Example Program Results
 
 Gauss-Legendre example
     4 Points     Answer =    3.14161
     8 Points     Answer =    3.14159
    16 Points     Answer =    3.14159
 
 
 Gauss-Rational example
     4 Points     Answer =     .37910
     8 Points     Answer =     .37876
    16 Points     Answer =     .37869
 
 
 Gauss-Laguerre example
     4 Points     Answer =     .04887
     8 Points     Answer =     .04890
    16 Points     Answer =     .04890
 
 
 Gauss-Hermite  example
     4 Points     Answer =    1.42803
     8 Points     Answer =    1.42817
    16 Points     Answer =    1.42817
