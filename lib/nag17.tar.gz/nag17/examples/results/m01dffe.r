 M01DFF Example Program Results
 
 Data                        Ranks
 
       6      5      4          2
       5      2      1          4
       2      4      9         10
       4      9      6          5
       4      9      5          7
       4      1      2          8
       3      4      1          9
       2      4      6         11
       1      6      4         12
       9      3      2          1
       6      2      5          3
       4      9      6          6
