 E02AKF Example Program Results
 
    I   Argument  Value of polynomial
    1    -.5000        .3679
    2     .5000        .7165
    3    1.5000       1.3956
    4    2.5000       2.7183
