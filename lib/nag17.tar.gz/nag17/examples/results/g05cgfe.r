 G05CGF Example Program Results
 
      .7951     .2257     .3713     .2250     .8787
      .0475     .1806     .3713     .2250     .8787
