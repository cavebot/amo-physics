 G05EDF Example Program Results
 
    54
    46
    48
    46
    56
