 F07MHF Example Program Results
 
 Solution(s)
             1          2
 1     -4.0000     1.0000
 2     -1.0000     4.0000
 3      2.0000     3.0000
 4      5.0000     2.0000
 
 Backward errors (machine-dependent)
       9.5D-17    2.3D-17
 Estimated forward error bounds (machine-dependent)
       2.4D-14    3.2D-14
