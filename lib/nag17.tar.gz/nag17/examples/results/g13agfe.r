 G13AGF Example Program Results
 
 The updated state set array now holds the values
    .0660  -.0513   .1716  -.0250   .0589   .1167   .1493   .0198
   -.1884  -.1289  -.1172   .1123  6.0039   .0444  -.0070   .0253
    .0019   .0354  -.0460   .0374   .0151  -.0237   .0032   .0188
    .0067   .0126
 
 The residuals corresponding to the 12
 values used to update the system are
    .0309   .0031   .0263   .0105   .0388  -.0333   .0265   .0238
   -.0159  -.0020   .0182   .0126
