 F07QVF Example Program Results
 
 Solution(s)
                    1                 2
 1  ( 1.0000,-1.0000) (-2.0000,-1.0000)
 2  (-2.0000, 5.0000) ( 1.0000,-3.0000)
 3  ( 3.0000,-2.0000) ( 3.0000, 2.0000)
 4  (-4.0000, 3.0000) (-1.0000, 1.0000)
 
 Backward errors (machine-dependent)
         6.4D-17           5.3D-17
 Estimated forward error bounds (machine-dependent)
         1.2D-14           1.2D-14
