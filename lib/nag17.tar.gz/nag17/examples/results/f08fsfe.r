 F08FSF Example Program Results
 
 Diagonal
   -2.2800   -.1285   -.1666  -1.9249
 Off-diagonal
   -4.3385  -2.0226  -1.8023
