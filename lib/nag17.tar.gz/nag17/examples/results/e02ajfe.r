 E02AJF Example Program Results
 
 Value of definite integral is     2.1515
