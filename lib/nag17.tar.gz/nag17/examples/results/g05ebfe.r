 G05EBF Example Program Results
 
     3
    -3
    -1
    -3
     4
