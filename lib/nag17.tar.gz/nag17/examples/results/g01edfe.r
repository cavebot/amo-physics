 G01EDF Example Program Results
 
    F      DF1     DF2    PROB
 
  5.500   1.500  25.500   .9837
 39.900   1.000   1.000   .9000
  2.500  20.250   1.000   .5342
