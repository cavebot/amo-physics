 F04QAF Example Program Results
 
 OUTPUT FROM F04QAF.
 
 LEAST-SQUARES SOLUTION OF  A*X = B
 
 THE MATRIX A HAS     13 ROWS AND     12 COLS
 THE DAMPING PARAMETER IS  DAMP =      0.00D+00
 
 ATOL =     1.00D-05     CONLIM =      1.00D+05
 BTOL =     1.00D-04     ITNLIM =    100
 
 NO. OF ITERATIONS  =      2
 STOPPING CONDITION =      2
 ( THE LEAST-SQRS SOLN IS GOOD ENOUGH, GIVEN ATOL )
 
 
 ACTUAL        NORM( RBAR ), NORM( X )        1.15D-02    4.33D+00
 NORM( TRANSPOSE( ABAR )*RBAR )               5.89D-15
 ESTIMATES OF  NORM( ABAR ), COND( ABAR )     4.12D+00    2.45D+00
 
 Solution returned by F04QAF
     1.250    1.250    1.250    1.247    1.247
     1.250    1.250    1.247    1.247    1.250
     1.250    1.250
 
 Norm of the residual =     1.15D-02
