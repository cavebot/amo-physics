 F04AJF Example Program Results
 
  Solution
    1.0000
   -2.0000
   -5.0000
