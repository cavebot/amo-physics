 S13AAF Example Program Results
 
      X           Y        IFAIL
 
    2.000D+00   4.890D-02      0
   -1.000D+00   0.000D+00      1
