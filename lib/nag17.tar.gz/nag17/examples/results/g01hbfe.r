 G01HBF Example Program Results
 
 Multivariate Normal probability =  .9142
