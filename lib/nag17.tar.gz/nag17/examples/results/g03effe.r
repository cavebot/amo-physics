 G03EFF Example Program Results
 
  The cluster each point belongs to
      1     1     3     2     3     1     1     2     2     3
      3     3     3     3     3     3     3     1     1     3
 
  The number of points in each cluster
      6     3    11
 
  The within-cluster sum of weights of each cluster
      6.00     3.00    11.00
 
  The within-cluster sum of squares of each cluster
       46.5717      20.3800     468.8964
 
  The final cluster centres
                  1       2       3       4       5
     1      81.1833 11.6667  7.1500  2.0500  6.6000
     2      47.8667 35.8000 16.3333  2.4000  6.7333
     3      64.0455 25.2091 10.7455  2.8364  6.6545
