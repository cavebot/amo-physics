 F07HUF Example Program Results
 
 Estimate of condition number =  1.22D+02
