 X04CDF Example Program Results
 
 Example 1:
             1          2          3          4
 1      1.0000
 2      2.0000     5.0000
 3      3.0000     6.0000     8.0000
 4      4.0000     7.0000     9.0000    10.0000
 
 Example 2:
               Un    Deux   Trois  Quatre    Cinq
     Uno     1.00    2.00    4.00    7.00   11.00
     Duo             1.00    5.00    8.00   12.00
     Tre                     1.00    9.00   13.00
 Quattro                             1.00   14.00
  Cinque                                     1.00
