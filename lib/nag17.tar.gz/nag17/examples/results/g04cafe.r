 G04CAF Example Program Results
 
  ANOVA table
 
   Source      df         SS          MS          F        Prob
 
 Blocks        2.      30119.      15059.       7.685      .0018
 Effect   1    5.      73008.      14602.       7.451      .0001
 Effect   2    2.      21596.      10798.       5.510      .0085
 Effect   3   10.      31192.       3119.       1.592      .1513
 Residual     34.      66628.       1960.
 Total        53.     222543.
 
  Treatment Means and Standard Errors
 
 Effect  1
 
    254.78    339.00    333.33    367.78    330.78    360.67
 
 SE of difference in means  =      20.87
 
 Effect  2
 
    334.28    353.78    305.11
 
 SE of difference in means  =      14.76
 
 Effect  3
 
    235.33    332.67    196.33    342.67    341.67    332.67    309.33    370.33
    320.33    395.00    370.33    338.00    373.33    326.67    292.33    350.00
    381.00    351.00
 
 SE of difference in means  =      36.14
 
