 F02FHF Example Program Results
 
 Eigenvalues
     .0544    .7578    .8277    .9188    .9429   1.1667   1.5582
    2.6623   4.7791
