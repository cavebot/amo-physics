 D05BEF Example Program Results
 
 Example 1
 
 The stepsize h =    .1000
 
      T        Approximate
                 Solution 
 
    .5000          .1191
   1.0000          .0528
   1.5000          .0265
   2.0000          .0146
   2.5000          .0086
   3.0000          .0052
   3.5000          .0033
   4.0000          .0022
   4.5000          .0014
   5.0000          .0010
   5.5000          .0007
   6.0000          .0004
   6.5000          .0003
   7.0000          .0002
 
 The maximum absolute error,    .29E-02, occurred at T =   .1000
 with solution    .0326

 
 Example 2
 
 The stepsize h =    .0714
 
      T        Approximate
                 Solution 
 
    .5000          .6667
   1.0000          .5000
   1.5000          .4000
   2.0000          .3333
   2.5000          .2857
   3.0000          .2500
   3.5000          .2222
   4.0000          .2000
   4.5000          .1818
   5.0000          .1667
 
 The maximum absolute error,    .32E-05, occurred at T =   .0714
 with solution    .9333

