 F01ALF Example Program Results
 
 Eigenvalues
  (  3.000,  4.000)
  (  3.000, -4.000)
 
 Eigenvectors
     .1200   -.1600
    1.0000    .0000
     .2000    .0000
     .1200   -.1600
