 G13DXF Example Program Results
 
         Eigenvalues       Moduli
         -----------       ------
       .802  +   .000 i      .802
       .575  +   .000 i      .575
