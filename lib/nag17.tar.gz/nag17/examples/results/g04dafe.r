 G04DAF Example Program Results
 
  ANOVA table
 
   Source        df         SS          MS          F        Prob
 
 Treatments    6.       972.3       162.1       3.608      .0103
 Residual     25.      1122.9        44.9
 Total        31.      2095.2
 
  Orthogonal Contrasts
 
 Cntl v S      1.       518.0       518.0      11.533      .0023
 Spring v A    1.       228.2       228.2       5.080      .0332
