 M01DCF Example Program Results
 
 Records ranked on columns  7  to 12
 
 Data            Ranks
 
 A02AAF   289      6
 A02ABF   523      5
 A02ACF   531      4
 C02ADF   169     10
 C02AEF   599      3
 C05ADF  1351      2
 C05AGF   240      7
 C05AJF   136     11
 C05AVF   211      8
 C05AXF   183      9
 C05AZF  2181      1
