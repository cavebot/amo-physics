 D02HBF Example Program Results
 
 
 Case 1
 
 Final parameters
       4.629D-02      3.494D-03
 
 Final solution
 X-value     Components of solution
     .10        .1025        .0173
    3.28        .1217        .0042
    6.46        .1338        .0036
    9.64        .1449        .0034
   12.82        .1557        .0034
   16.00        .1667        .0035
 
 
 Case 2
 
 Final parameters
       3.239D+01      5.962D+03     -5.353D-01
 
 Final solution
 X-value     Components of solution
      0.           .0        500.0         .500
   1192.        529.6        451.6         .328
   2385.        807.2        420.3         .123
   3577.        820.4        409.4        -.103
   4769.        556.1        420.0        -.330
   5962.           .0        450.0        -.535
