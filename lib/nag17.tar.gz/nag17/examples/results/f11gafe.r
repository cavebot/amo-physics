 F11GAF Example Program Results

 Monitoring at iteration no.   2
 residual norm:     1.9938D+00
  Solution vector  Residual vector
       9.6320D-01      -2.2960D-01
       1.9934D+00       2.2254D-01
       3.0583D+00       9.5827D-02
       4.1453D+00      -2.5155D-01
       4.8289D+00      -1.7160D-01
       5.6630D+00       6.7533D-01
       7.1062D+00      -3.4737D-01

 Monitoring at iteration no.   4
 residual norm:     6.6574D-03
  Solution vector  Residual vector
       9.9940D-01      -1.0551D-03
       2.0011D+00      -2.4675D-03
       3.0008D+00      -1.7116D-05
       3.9996D+00       4.4929D-05
       4.9991D+00       2.1359D-03
       5.9993D+00      -8.7482D-04
       7.0007D+00       6.2045D-05

 Final Results
 Number of iterations for convergence:       5
 Residual norm:                               9.7700D-15
 Right-hand side of termination criterion:    3.9200D-04
 1-norm of matrix A:                          1.0000D+01
 Largest singular value of A_bar:             1.3596D+00
  Solution vector  Residual vector
       1.0000D+00       0.0000D+00
       2.0000D+00       3.5527D-15
       3.0000D+00      -8.8818D-16
       4.0000D+00       0.0000D+00
       5.0000D+00       0.0000D+00
       6.0000D+00      -1.7764D-15
       7.0000D+00       3.5527D-15
