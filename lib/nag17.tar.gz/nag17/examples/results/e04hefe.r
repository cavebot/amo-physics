 E04HEF Example Program Results
 
 On exit, the sum of squares is       .0082
 at the point       .0824      1.1330      2.3437
 The corresponding gradient is  -6.058D-12   9.030D-11   9.385D-11
                            (machine dependent)
 and the residuals are
  -5.9D-03
  -2.7D-04
   2.7D-04
   6.5D-03
  -8.2D-04
  -1.3D-03
  -4.5D-03
  -2.0D-02
   8.2D-02
  -1.8D-02
  -1.5D-02
  -1.5D-02
  -1.1D-02
  -4.2D-03
   6.8D-03
