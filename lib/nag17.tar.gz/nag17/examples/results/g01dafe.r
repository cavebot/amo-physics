 G01DAF Example Program Results
 
 Set size =  5
 Error tolerance (input) =      .100D-02
 Error estimate (output) =      .908D-08
 Normal scores
              -1.163     -.495      .000      .495     1.163
 
 Set size = 10
 Error tolerance (input) =      .100D-02
 Error estimate (output) =      .148D-07
 Normal scores
              -1.539    -1.001     -.656     -.376     -.123
                .123      .376      .656     1.001     1.539
 
 Set size = 15
 Error tolerance (input) =      .100D-02
 Error estimate (output) =      .222D-07
 Normal scores
              -1.736    -1.248     -.948     -.715     -.516
               -.335     -.165      .000      .165      .335
                .516      .715      .948     1.248     1.736
