 D01AJF Example Program Results
 
 A      - lower limit of integration =      .0000
 B      - upper limit of integration =     6.2832
 EPSABS - absolute accuracy requested =   .00D+00
 EPSREL - relative accuracy requested =   .10D-03
 
 RESULT - approximation to the integral =  -2.54326
 ABSERR - estimate of the absolute error =   .13D-04
 KOUNT  - number of function evaluations =  777
 IW(1)  - number of subintervals used =   19
