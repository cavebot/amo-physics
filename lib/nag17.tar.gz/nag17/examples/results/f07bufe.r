 F07BUF Example Program Results
 
 Estimate of condition number =  1.04D+02
