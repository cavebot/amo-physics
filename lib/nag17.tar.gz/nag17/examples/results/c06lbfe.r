 C06LBF Example Program Results
 
 No. of coefficients returned by C06LBF =    64
 
                  Computed          Exact      Pseudo
          t           f(t)           f(t)       error
 
   0.00D+00     1.5129D-09     0.0000D+00     1.5D-09
   1.00D+00     1.0018D+01     1.0018D+01     1.7D-09
   2.00D+00     2.0171D+02     2.0171D+02     1.2D-10
   3.00D+00     4.0515D+03     4.0515D+03     9.8D-10
   4.00D+00     8.1377D+04     8.1377D+04     3.0D-10
   5.00D+00     1.6345D+06     1.6345D+06     1.7D-09
