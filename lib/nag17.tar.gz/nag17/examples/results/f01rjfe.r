 F01RJF Example Program Results
 
 RQ factorization of A
 
 Vector THETA
 ( 1.039, -.101) ( 1.181,  .381) ( 1.224,  .000)
 
 Matrix A after factorization (R is in left-hand upper triangle)
 (  .788,  .000) ( -.255, -.401) ( -.277, -.277) ( -.285,  .559) (  .115,  .703)
 (  .040,  .522) (-2.112,  .000) (-1.109, -.555) (  .128,  .232) (  .079, -.036)
 ( -.227,  .227) (  .045,  .317) (-3.606,  .000) (  .000,  .000) (  .000,  .544)
