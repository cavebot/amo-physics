 F02ANF Example Program Results
 
 Eigenvalues
  (  3.000, -9.000)
  (  4.000, -5.000)
  (  2.000, -5.000)
  (  3.000, -1.000)
