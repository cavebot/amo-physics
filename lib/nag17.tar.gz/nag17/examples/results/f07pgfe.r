 F07PGF Example Program Results
 
 Estimate of condition number =  7.57D+01
