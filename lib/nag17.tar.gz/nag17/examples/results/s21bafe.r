 S21BAF Example Program Results
 
     X      Y        S21BAF  IFAIL
 
     .50   1.00      1.1107    0
    1.00   1.00      1.0000    0
    1.50   1.00       .9312    0
