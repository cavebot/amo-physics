 G07CAF Example Program Results
 
 Assuming population variances are equal.
 
 t test statistic =     1.8403
 Degrees of freedom =     10.0
 Significance level =    .0955
 Lower confidence limit for difference in means =     -.8429
 Upper confidence limit for difference in means =     8.8429
 
 
 No assumptions about population variances .
 
 t test statistic =     2.5922
 Degrees of freedom =   7.9925
 Significance level =    .0320
 Lower confidence limit for difference in means =      .4410
 Upper confidence limit for difference in means =     7.5590
