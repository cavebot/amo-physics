 E04ZCF Example Program Results
 
 Derivatives probably correct at the point
   1.1000D+00  1.2000D+00  1.3000D+00  1.4000D+00  1.5000D+00
   1.6000D+00  1.7000D+00  1.8000D+00  1.9000D+00
 
 Derivatives probably correct at the point
   1.1000D+00  2.2000D+00  3.3000D+00  4.4000D+00  5.5000D+00
   6.6000D+00  7.7000D+00  8.8000D+00  9.9000D+00
