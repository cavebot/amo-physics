 G02BEF Example Program Results
 
 Number of variables (columns) = 3
 Number of cases     (rows)    = 5
 
 Data matrix is:-
 
            1           2           3
   1      2.0000      3.0000      3.0000
   2      4.0000      6.0000      4.0000
   3      9.0000      9.0000       .0000
   4       .0000     12.0000      2.0000
   5     12.0000     -1.0000      5.0000
 
 Variable   Mean    St. dev.
     1     6.0000     5.2915
     2     2.6667     3.5119
     3     4.0000     1.0000
 
 Sums of squares and cross-products about zero
            1           2           3
   1    164.0000     18.0000     82.0000
   2     18.0000     46.0000     28.0000
   3     82.0000     28.0000     50.0000
 
 Correlation-like coefficients
            1           2           3
   1      1.0000       .2072       .9055
   2       .2072      1.0000       .5838
   3       .9055       .5838      1.0000
 
 Number of cases actually used:  3
