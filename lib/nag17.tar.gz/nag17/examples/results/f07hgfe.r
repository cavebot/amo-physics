 F07HGF Example Program Results
 
 Estimate of condition number =  7.42D+01
