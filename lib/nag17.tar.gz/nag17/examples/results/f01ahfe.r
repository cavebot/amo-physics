 F01AHF Example Program Results
 
 Eigenvalues
   -1.0000   2.0000
 
 Eigenvectors
    -.1000    .1000
    -.7000    .7000
    -.5000   -.5000
    -.5000   -.5000
