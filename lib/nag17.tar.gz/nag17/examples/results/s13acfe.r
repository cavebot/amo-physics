 S13ACF Example Program Results
 
      X           Y        IFAIL
 
    2.000D-01  -1.042D+00      0
    4.000D-01  -3.788D-01      0
    6.000D-01  -2.227D-02      0
    8.000D-01   1.983D-01      0
    1.000D+00   3.374D-01      0
