 G13ACF Example Program Results
 
 Lag  Partial    Predictor error  Autoregressive
      autocorrn  variance ratio   parameter
 
  1     .800            .359         1.108
  2    -.571            .242         -.290
  3    -.239            .228         -.193
  4    -.049            .228         -.014
  5    -.032            .228         -.032
