 D01AHF Example Program Results
 
 Integral =  3.14159
 
 Estimated relative error =    .58D-08
 
 Number of function evaluations =   15
