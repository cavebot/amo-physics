 G02CFF Example Program Results
 
 Original vector XM   :       5.4000    5.8000    2.8000
 
 Original vector STD  :       4.9800    5.0695    1.9240
 
 Original matrix SSP  :
    99.2000  -57.6000    6.4000
   -57.6000  102.8000  -29.2000
     6.4000  -29.2000   14.8000
 
 Original matrix CORR :
     1.0000    -.5704     .1670
     -.5704    1.0000    -.7486
      .1670    -.7486    1.0000
 
 New vector XM   :       5.4000    2.8000    5.8000
 
 New vector STD  :       4.9800    1.9240    5.0695
 
 New matrix SSP  :
    99.2000    6.4000  -57.6000
     6.4000   14.8000  -29.2000
   -57.6000  -29.2000  102.8000
 
 New matrix CORR :
     1.0000     .1670    -.5704
      .1670    1.0000    -.7486
     -.5704    -.7486    1.0000
