 F07GHF Example Program Results
 
 Solution(s)
             1          2
 1      1.0000     4.0000
 2     -1.0000     3.0000
 3      2.0000     2.0000
 4     -3.0000     1.0000
 
 Backward errors (machine-dependent)
       4.0D-17    3.7D-17
 Estimated forward error bounds (machine-dependent)
       2.3D-14    2.2D-14
