 G05ECF Example Program Results
 
     4
     1
     2
     1
     5
