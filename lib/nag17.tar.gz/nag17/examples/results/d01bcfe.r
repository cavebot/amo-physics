 D01BCF Example Program Results
 
 Laguerre formula,  7 points
 
       Abscissae             Weights
 
      .19304D+00          .49648D+00
      .10267D+01          .11776D+01
      .25679D+01          .19182D+01
      .49004D+01          .27718D+01
      .81822D+01          .38412D+01
      .12734D+02          .53807D+01
      .19396D+02          .84054D+01
