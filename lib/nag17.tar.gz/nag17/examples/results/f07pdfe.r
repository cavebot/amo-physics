 F07PDF Example Program Results
 
 Details of factorization
             1          2          3          4
 1      2.0700
 2      4.2000     1.1500
 3       .2230      .8115    -2.5907
 4       .6537     -.5960      .3031      .4074
 
 IPIV
            -3         -3          3          4
