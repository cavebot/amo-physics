 G02BGF Example Program Results
 
 Number of variables (columns) = 4
 Number of cases     (rows)    = 5
 
 Data matrix is:-
 
            1           2           3           4
   1      3.0000      3.0000      1.0000      2.0000
   2      6.0000      4.0000     -1.0000      4.0000
   3      9.0000       .0000      5.0000      9.0000
   4     12.0000      2.0000       .0000       .0000
   5     -1.0000      5.0000      4.0000     12.0000
 
 Variable   Mean    St. dev.
     4     5.4000     4.9800
     1     5.8000     5.0695
     2     2.8000     1.9235
 
 Sums of squares and cross-products of deviations
            4           1           2
   4     99.2000    -57.6000      6.4000
   1    -57.6000    102.8000    -29.2000
   2      6.4000    -29.2000     14.8000
 
 Correlation coefficients
            4           1           2
   4      1.0000      -.5704       .1670
   1      -.5704      1.0000      -.7486
   2       .1670      -.7486      1.0000
