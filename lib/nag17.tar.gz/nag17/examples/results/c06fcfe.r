 C06FCF Example Program Results
 
 Components of discrete Fourier transform
 
           Real      Imag
 
     0   2.48361   -.47100
     1   -.55180    .49684
     2   -.36711    .09756
     3   -.28767   -.05865
     4   -.22506   -.17477
     5   -.14825   -.30840
     6    .01983   -.56496
 
 Original sequence as restored by inverse transform
 
              Original                 Restored
           Real      Imag           Real      Imag
 
     0    .34907   -.37168         .34907   -.37168
     1    .54890   -.35669         .54890   -.35669
     2    .74776   -.31175         .74776   -.31175
     3    .94459   -.23702         .94459   -.23702
     4   1.13850   -.13274        1.13850   -.13274
     5   1.32850    .00074        1.32850    .00074
     6   1.51370    .16298        1.51370    .16298
