 G01DDF Example Program Results
 
 For sample number 1, value of W statistic =   .8992
                      Significance level is    .0408
 
 For sample number 2, value of W statistic =   .9583
                      Significance level is    .5171
