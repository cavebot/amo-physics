 G01EAF Example Program Results
 
  Tail    X      Probability 
 
   L    1.96        .9750
   U    1.96        .0250
   C    1.96        .9500
   S    1.96        .0500
