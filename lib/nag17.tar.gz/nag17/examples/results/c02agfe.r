 C02AGF Example Program Results
 
 Degree of polynomial =    5
 
 Roots of polynomial
 
 Z =  -1.4918D+00
 Z =   5.5169D-01 +/-   1.2533D+00*i
 Z =  -8.0579D-01 +/-   1.2229D+00*i
