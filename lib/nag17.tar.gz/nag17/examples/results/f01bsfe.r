 F01BSF Example Program Results
 
 On exit from F01BRF
 Value of W(1)  = 18.0000
 
 On exit from F01BSF
 Value of W(1)  = 51.0000
 
 Value of RPMIN =   .1000
