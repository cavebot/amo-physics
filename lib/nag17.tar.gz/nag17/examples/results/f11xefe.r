 F11XEF Example Program Results
  Matrix-vector product
        .4100D+01
       -.2940D+01
        .1410D+01
        .2530D+01
        .4350D+01
        .1290D+01
        .5010D+01
        .5200D+00
        .4570D+01
