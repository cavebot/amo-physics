 C06LAF Example Program Results
 
 (results may be machine-dependent)
 
 Test with T(1) = 1.0
 
   MXTERM = 200  TFAC =  7.50  ALPHAB =  -.50  RELERR = 1.0D-02
 
    T        Result        exp(-T/2)   Relative error  Error estimate
  1.0         .607           .607          .1D-02          .4D-02
 
  NTERMS =  18  NFEVAL =  36  ALOW =   -.04  AHIGH =    .09  IFAIL = 0
 
 Test with T(1) = 1.0
 
   MXTERM = 200  TFAC =   .80  ALPHAB =  -.50  RELERR = 1.0D-03
 
    T        Result        exp(-T/2)   Relative error  Error estimate
  1.0         .607           .607          .2D-04          .8D-04
 
  NTERMS =  13  NFEVAL =  28  ALOW =   5.26  AHIGH =   6.51  IFAIL = 0
 
 Compute inverse
 
   MXTERM = 200  TFAC =   .80  ALPHAB =  -.50  RELERR = 1.0D-03
 
    T        Result        exp(-T/2)   Relative error  Error estimate
  1.0         .607           .607          .5D-04          .3D-03
  2.0         .368           .368          .7D-05          .9D-04
  3.0         .223           .223          .2D-04          .8D-04
  4.0         .135           .135          .1D-04          .8D-04
  5.0         .082           .082          .2D-04          .8D-04
 
  NTERMS =  23  NFEVAL =  43  ALOW =    .65  AHIGH =    .90  IFAIL = 0
