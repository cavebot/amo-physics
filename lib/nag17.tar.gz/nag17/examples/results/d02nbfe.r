 D02NBF Example Program Results
 
   Numerical Jacobian
 
     X          Y(1)           Y(2)           Y(3)
     .000      1.00000         .00000         .00000
   10.000       .84136         .00002         .15863
 
  HUSED =   .51867D+00  HNEXT =   .51867D+00  TCUR =   .10000D+02
  NST =     55    NRE =    132    NJE =     17
  NQU =      3    NQ  =      3  NITER =     79
  Max Err Comp =    3
 
 
   Analytic Jacobian
 
     X          Y(1)           Y(2)           Y(3)
     .000      1.00000         .00000         .00000
   10.000       .84136         .00002         .15863
 
  HUSED =   .51867D+00  HNEXT =   .51867D+00  TCUR =   .10000D+02
  NST =     55    NRE =     81    NJE =     17
  NQU =      3    NQ  =      3  NITER =     79
  Max Err Comp =    3
 
