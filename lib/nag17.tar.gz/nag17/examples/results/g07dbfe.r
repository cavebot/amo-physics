 G07DBF Example Program Results
 
           Input parameters     Output parameters
 ISIGMA   SIGMA   THETA   TOL    SIGMA  THETA
   1    -1.0000   .0000  .0001   6.3247 10.5487
   1     7.0000  2.0000  .0001   6.3249 10.5487
   0    -1.0000   .0000  .0001   5.9304 10.4896
   0     7.0000  2.0000  .0001   7.0000 10.6500
