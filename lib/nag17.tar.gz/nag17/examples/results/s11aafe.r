 S11AAF Example Program Results
 
      X           Y        IFAIL
 
   -5.000D-01  -5.493D-01      0
    0.000D+00   0.000D+00      0
    5.000D-01   5.493D-01      0
   -9.999D-01  -4.952D+00      0
    3.000D+00   0.000D+00      1
