 G07DAF Example Program Results
 
 Output Y:
   3.000  5.000  6.000  7.000  8.000  9.000 11.000 13.000 16.000 18.000 27.000
 
 XME =  9.000, XMD =  4.000, XSD =  5.930
