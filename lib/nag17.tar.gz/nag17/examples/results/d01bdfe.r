 D01BDF Example Program Results
 
 A      - lower limit of integration =      .0000
 B      - upper limit of integration =     1.0000
 EPSABS - absolute accuracy requested =   .00D+00
 EPSREL - relative accuracy requested =   .10D-03
 
 RESULT - approximation to the integral =   -.03183
 ABSERR - estimate to the absolute error =   .13D-10
 KOUNT  - number of function evaluations =   43
 
