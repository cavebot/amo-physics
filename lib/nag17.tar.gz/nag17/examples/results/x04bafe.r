 X04BAF Example Program Results
 
 This record was output by X04BAF
