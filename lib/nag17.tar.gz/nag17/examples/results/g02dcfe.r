 G02DCF Example Program Results
 
 Results from G02DAF
 Residual sum of squares =    .5275D+04
 Degrees of freedom =    8
 
 Variable   Parameter estimate   Standard error
 
      1           .2072D+02           .1380D+02
      2           .1409D+02           .1624D+02
      3           .2632D+02           .1380D+02
      4           .2260D+02           .1380D+02
 
 Results from dropping an observation using G02DCF
 Residual sum of squares =    .2170D+02
 Degrees of freedom =    7
 
 Variable   Parameter estimate   Standard error
 
      1           .3600D+02           .1017D+01
      2           .3701D+02           .1245D+01
      3           .4160D+02           .1017D+01
      4           .3788D+02           .1017D+01
 
 Results from adding an observation using G02DCF
 Residual sum of squares =    .2223D+02
 Degrees of freedom =    8
 
 Variable   Parameter estimate   Standard error
 
      1           .3600D+02           .9623D+00
      2           .3730D+02           .9623D+00
      3           .4160D+02           .9623D+00
      4           .3788D+02           .9623D+00
