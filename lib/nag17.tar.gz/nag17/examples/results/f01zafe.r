 F01ZAF Example Program Results
 
 Unpacked Matrix A:
       1    2    3    4
 1  1.10 1.20 1.30 1.40
 2       2.20 2.30 2.40
 3            3.30 3.40
 4                 4.40
 
 Packed Vector B:
  1  1.10
  2  1.20
  3  2.20
  4  1.30
  5  2.30
  6  3.30
  7  1.40
  8  2.40
  9  3.40
 10  4.40
