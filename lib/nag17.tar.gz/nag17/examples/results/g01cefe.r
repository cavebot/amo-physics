 G01CEF Example Program Results
 
   Prob.   Deviate
 
    .950     1.6449
    .500      .0000
    .000     Failed in G01CEF. IFAIL = 1
    .995     2.5758
    .750      .6745
   2.000     Failed in G01CEF. IFAIL = 1
    .001    -3.0902
