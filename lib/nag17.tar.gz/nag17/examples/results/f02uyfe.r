 F02UYF Example Program Results
 
 Singular values of the bidiagonal matrix
   3.9264   2.0000    .7641
 
 Vector Q'*B
 (-1.9655,  -.7935) (  .1132,  -.3397) (  .0915,   .6086)
