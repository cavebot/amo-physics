 F04KLF Example Program Results
 
 Least-squares solution
    (-1.0000, 2.0000) ( 4.0000,-5.0000) (-3.0000, 1.0000)
