 D05BDF Example Program Results
 
 Example 1
 
 The stepsize h =    .1000
 
      T        Approximate
                 Solution 
 
    .0000          .0000
    .5000          .7071
   1.0000         1.0000
   1.5000         1.2247
   2.0000         1.4142
   2.5000         1.5811
   3.0000         1.7321
   3.5000         1.8708
   4.0000         2.0000
   4.5000         2.1213
   5.0000         2.2361
   5.5000         2.3452
   6.0000         2.4495
   6.5000         2.5495
   7.0000         2.6458
 
 The maximum absolute error,    .11E-07, occurred at T =  1.2000
 with solution   1.0954

 Example 2
 
 The stepsize h =    .0714
 
      T        Approximate
                 Solution 
 
    .0000          .0000
    .5000          .3536
   1.0000          .0000
   1.5000         -.6124
   2.0000        -1.4142
   2.5000        -2.3717
   3.0000        -3.4641
   3.5000        -4.6771
   4.0000        -6.0000
   4.5000        -7.4246
   5.0000        -8.9443
 
 The maximum absolute error,    .43E-07, occurred at T =  4.3571
 with solution  -7.0076

