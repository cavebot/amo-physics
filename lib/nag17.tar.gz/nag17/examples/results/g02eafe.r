 G02EAF Example Program Results
 
 Number of     RSS    RANK         MODEL
 parameters
        0     5.0634  32   
        1     5.0219  31    TKN
        1     2.5044  30    TVS
        1     2.0338  28    BOD
        1     1.5563  25    COD
        1     1.5370  24    TS 
        2     2.4381  29    TKN TVS
        2     1.7462  27    BOD TVS
        2     1.5921  26    BOD TKN
        2     1.4963  23    BOD COD
        2     1.4707  22    TKN TS 
        2     1.4590  21    TS  TVS
        2     1.4397  20    BOD TS 
        2     1.4388  19    TKN COD
        2     1.3287  15    TVS COD
        2     1.0850   8    TS  COD
        3     1.4257  18    BOD TKN TVS
        3     1.3900  17    TKN TS  TVS
        3     1.3894  16    BOD TS  TVS
        3     1.3204  14    BOD TVS COD
        3     1.2764  13    BOD TKN COD
        3     1.2582  12    BOD TKN TS 
        3     1.2179  10    TKN TVS COD
        3     1.0644   7    BOD TS  COD
        3     1.0634   6    TS  TVS COD
        3      .9871   4    TKN TS  COD
        4     1.2199  11    BOD TKN TS  TVS
        4     1.1565   9    BOD TKN TVS COD
        4     1.0388   5    BOD TS  TVS COD
        4      .9871   3    BOD TKN TS  COD
        4      .9653   2    TKN TS  TVS COD
        5      .9652   1    BOD TKN TS  TVS COD
