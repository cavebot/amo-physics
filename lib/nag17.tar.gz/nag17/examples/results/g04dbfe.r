 G04DBF Example Program Results
 
  ANOVA table
 
   Source        df         SS          MS          F        Prob
 
 Treatments    3.       239.9        80.0      24.029      .0000
 Residual     22.        73.2         3.3
 Total        25.       313.1
 
  Treatment means
 
   3.000   7.000   2.250   9.429
 
  Simultaneous Confidence Intervals
 
   2 1         .933        7.067   *
   3 1       -3.486        1.986    
   3 2       -7.638       -1.862   *
   4 1        3.610        9.247   *
   4 2        -.538        5.395    
   4 3        4.557        9.800   *
