 D01PAF Example Program Results
 
 MAXORD   Estimated      Estimated         Integrand
            value         accuracy        evaluations
    1       .25816        .258D+00              1
    2       .25011        .806D-02              5
    3       .25000        .107D-03             15
    4       .25000        .410D-06             35
    5       .25000        .173D-08             70
