 F02SYF Example Program Results
 
 Singular value decomposition of A
 
 Singular values
   6.5616   3.0000   2.4385
 
 Left-hand singular vectors, by column
   -.7699    .5883   -.2471
   -.6376   -.6934    .3357
   -.0262   -.4160   -.9090
 
 Right-hand singular vectors, by column
    .4694   -.7845    .4054
    .8804    .3808   -.2826
    .0673    .4895    .8694
