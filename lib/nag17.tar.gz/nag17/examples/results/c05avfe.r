 C05AVF Example Program Results
 
 Interval containing root is (Y,X) where
 Y =      2.5000   X =      1.7000
 Values of f at Y and X are
 f(Y) =         .75   f(X) =        -.21
