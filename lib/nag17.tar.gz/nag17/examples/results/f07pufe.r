 F07PUF Example Program Results
 
 Estimate of condition number =  6.68D+00
