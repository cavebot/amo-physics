 F07FJF Example Program Results
 
 Inverse
             1          2          3          4
 1       .6995
 2       .7769     1.4239
 3       .7508     1.8255     4.0688
 4      -.9340    -1.8841    -2.9342     3.4978
