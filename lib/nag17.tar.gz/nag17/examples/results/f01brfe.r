 F01BRF Example Program Results
 
 Number of non-zeros in decomposition         =   16
 Minimum size of array IRN                    =   15
 Minimum size of arrays A and ICN             =   19
 Number of compresses on IRN (IDISP(3))       =    0
 Number of compresses on A and ICN (IDISP(4)) =    0
 
 Value of W(1) = 18.0000
 
 Structural rank                =    6
 Number of diagonal blocks      =    3
 Size of largest diagonal block =    4
