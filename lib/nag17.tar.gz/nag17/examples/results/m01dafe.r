 M01DAF Example Program Results
 
    Data   Ranks
 
     5.3      7
     4.6      6
     7.8     10
     1.7      2
     5.3      8
     9.9     12
     3.2      3
     4.3      4
     7.8     11
     4.5      5
     1.2      1
     7.6      9
