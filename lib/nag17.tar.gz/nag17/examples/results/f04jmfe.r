 F04JMF Example Program Results
 
 Constrained least-squares solution
     .4857    .9956    .4857    .9956
 
 Residual sum of squares =   2.95D+01
