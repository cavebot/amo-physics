 G03DAF Example Program Results
 
  Group means
 
     1.0433    -.6034
     2.0073    -.2060
     2.7097    1.5998
 
  LOG of determinants
 
     -.8273   -3.0460   -2.2877
 
  STAT = 19.2410
    DF =  6.0000
   SIG =   .0038
