 F04AMF Example Program Results
 
  Solution
    1.3010
     .7935
