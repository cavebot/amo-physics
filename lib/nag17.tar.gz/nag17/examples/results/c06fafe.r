 C06FAF Example Program Results
 
 Components of discrete Fourier transform
 
           Real      Imag
 
     0   2.48361    .00000
     1   -.26599    .53090
     2   -.25768    .20298
     3   -.25636    .05806
     4   -.25636   -.05806
     5   -.25768   -.20298
     6   -.26599   -.53090
 
 Original sequence as restored by inverse transform
 
         Original  Restored
 
     0    .34907    .34907
     1    .54890    .54890
     2    .74776    .74776
     3    .94459    .94459
     4   1.13850   1.13850
     5   1.32850   1.32850
     6   1.51370   1.51370
