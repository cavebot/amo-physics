 G08RAF Example Program Results
 
 Number of samples = 1
 Number of parameters fitted = 2
 Distribution = 2
 Tolerance for ties =  .00001
 
 Score statistic
    -1.048   64.333
 
 Covariance matrix of score statistic
      .673
    -4.159  533.670
 
 Parameter estimates
     -.852     .114
 
 Covariance matrix of parameter estimates
     1.560
      .012     .002
 
 Chi-squared statistic =    8.221 with 2 d.f.
 
 Standard errors of estimates and
 approximate z-statistics
     1.249         -.682
      .044         2.567
