 S15ADF Example Program Results
 
      X           Y        IFAIL
 
   -1.000D+01   2.000D+00      0
   -1.000D+00   1.843D+00      0
    0.000D+00   1.000D+00      0
    1.000D+00   1.573D-01      0
    1.000D+01   2.088D-45      0
