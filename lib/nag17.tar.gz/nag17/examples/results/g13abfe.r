 G13ABF Example Program Results
 
 The first 10 coefficients are required
 The input array has sample mean      37.4180
 The input array has sample variance    1002.0301
 The sample autocorrelation coefficients are
 
    Lag    Coeff      Lag    Coeff
      1     .8004       2     .4355
      3     .0328       4    -.2835
      5    -.4505       6    -.4242
      7    -.2419       8     .0550
      9     .3783      10     .5857
 
 The value of STAT is      92.1231
