 G08AFF Example Program Results
 
 Kruskal-Wallis test
 
 Data values
 
   Group    Observations
     1      23. 27. 26. 19. 30.
     2      29. 25. 33. 36. 32. 28. 30. 31.
     3      38. 31. 28. 35. 33. 36.
     4      30. 27. 28. 22. 33. 34. 34. 32.
     5      31. 33. 31. 28. 30. 24. 29. 30.
 
 Test statistic          10.537
 Degrees of freedom           4
 Significance              .032
