 F08SSF Example Program Results
 
 Eigenvalues
    -5.9990 -2.9936   .5047  3.9990
