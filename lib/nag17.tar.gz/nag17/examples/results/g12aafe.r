 G12AAF Example Program Results
 
   Time   Survival    Standard
         probability  deviation
 
    6.0      .857        .076
    7.0      .807        .087
   10.0      .753        .096
   13.0      .690        .107
   16.0      .627        .114
   22.0      .538        .128
   23.0      .448        .135
