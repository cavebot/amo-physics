 G02CDF Example Program Results
 
  Case     Independent     Dependent
 number     variable       variable
 
    1         1.0000        20.0000
    2          .0000        15.5000
    3         4.0000        28.3000
    4         7.5000        45.0000
    5         2.5000        24.5000
    6          .0000        10.0000
    7        10.0000        99.0000
    8         5.0000        31.2000
 
 Mean of independent variable               =   4.0000
 Mean of   dependent variable               =  29.8000
 Standard deviation of independent variable =   2.4749
 Standard deviation of   dependent variable =   9.4787
 Correlation coefficient                    =    .9799
 
 Regression coefficient                     =   6.5833
 Standard error of coefficient              =    .8046
 t-value for coefficient                    =   8.1816
 
 Analysis of regression table :-
 
       Source        Sum of squares  D.F.    Mean square     F-value
 
 Due to regression     4528.9493      1.     4528.9493       66.9392
 About  regression      270.6307      4.       67.6577
 Total                 4799.5800      5.
 
 Number of cases used =  5.
