 M01EBF Example Program Results
 
 Matrix sorted on column  1
 
       1      6      4
       2      4      9
       2      4      6
       3      4      1
       4      9      6
       4      9      5
       4      1      2
       4      9      6
       5      2      1
       6      5      4
       6      2      5
       9      3      2
