 G03EAF Example Program Results
 
  Distance Matrix
 
         1       2       3       4
 
  2      1.00
  3     29.00   26.00
  4     50.00   49.00    5.00
  5     50.00   53.00   13.00    4.00
