 A02AAF Example Program Results
 
    XR    XI      YR       YI
   -1.7   2.6    .8386   1.5502
