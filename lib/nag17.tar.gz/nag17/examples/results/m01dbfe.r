 M01DBF Example Program Results
 
    Data   Ranks
 
      34      9
      44      8
      89      2
      64      7
      69      4
      69      5
      23     10
       1     12
     999      1
      65      6
      22     11
      76      3
