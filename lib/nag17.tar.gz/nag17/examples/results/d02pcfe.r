 D02PCF Example Program Results

 Calculation with TOL =   .1D-02

    t         y1        y2

   .000      .000     1.000
   .785      .707      .707
  1.571      .999      .000
  2.356      .706     -.706
  3.142      .000     -.999
  3.927     -.706     -.706
  4.712     -.998      .000
  5.498     -.705      .706
  6.283      .001      .997

 Cost of the integration in evaluations of F is   124

 Calculation with TOL =   .1D-03

    t         y1        y2

   .000      .000     1.000
   .785      .707      .707
  1.571     1.000      .000
  2.356      .707     -.707
  3.142      .000    -1.000
  3.927     -.707     -.707
  4.712    -1.000      .000
  5.498     -.707      .707
  6.283      .000     1.000

 Cost of the integration in evaluations of F is   235
