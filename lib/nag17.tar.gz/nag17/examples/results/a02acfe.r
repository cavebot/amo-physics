 A02ACF Example Program Results
 
    XR    XI    YR    YI      ZR       ZI
   -1.7   2.6  -3.1   -.9    .2812   -.9203
