 G03CCF Example Program Results
 
  Loadings, Communalities and PSI
 
      .553   -.429    .490    .510
      .568   -.288    .406    .594
      .392   -.450    .356    .644
      .740    .273    .623    .377
      .724    .211    .569    .431
      .595    .132    .372    .628
 
  Factor score coefficients
 
      .193   -.392
      .170   -.226
      .109   -.326
      .349    .337
      .299    .229
      .169    .098
