 G07DDF Example Program Results
 
 Statistics from middle  75.00% of data
 
                Trimmed-mean =      8.8333
    Variance of Trimmed-mean =      1.5434
 
             Winsorized-mean =      9.1250
 Variance of Winsorized-mean =      1.5381
