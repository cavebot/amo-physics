 C06FBF Example Program Results
 
 Original sequence and corresponding complex sequence
 
          Data           Real      Imag
 
     0    .34907         .34907    .00000
     1    .54890         .54890   1.51370
     2    .74776         .74776   1.32850
     3    .94459         .94459   1.13850
     4   1.13850         .94459  -1.13850
     5   1.32850         .74776  -1.32850
     6   1.51370         .54890  -1.51370
 
 Components of discrete Fourier transform
 
     0   1.82616
     1   1.86862
     2   -.01750
     3    .50200
     4   -.59873
     5   -.03144
     6  -2.62557
 
 Original sequence as restored by inverse transform
 
         Original  Restored
 
     0    .34907    .34907
     1    .54890    .54890
     2    .74776    .74776
     3    .94459    .94459
     4   1.13850   1.13850
     5   1.32850   1.32850
     6   1.51370   1.51370
