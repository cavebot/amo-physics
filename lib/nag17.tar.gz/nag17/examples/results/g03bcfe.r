 G03BCF Example Program Results
 
          Rotation Matrix
 
     .967     .254
    -.254     .967
 
  Scale factor =      1.556
 
         Target Matrix
 
     .000     .000
    1.000     .000
     .000    2.000
 
         Fitted Matrix
 
    -.093     .024
    1.080     .026
     .013    1.950
 
 RSS =       .019
