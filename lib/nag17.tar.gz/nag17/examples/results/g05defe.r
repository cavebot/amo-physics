 G05DEF Example Program Results
 
     6.0767
    18.9017
    29.0802
     2.6121
    26.4446
