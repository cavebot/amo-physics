 S10AAF Example Program Results
 
      X           Y        IFAIL
 
   -2.000D+01  -1.000D+00      0
   -5.000D+00  -9.999D-01      0
    5.000D-01   4.621D-01      0
    5.000D+00   9.999D-01      0
