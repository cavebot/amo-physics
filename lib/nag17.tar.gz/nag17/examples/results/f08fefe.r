 F08FEF Example Program Results
 
 Diagonal
    2.0700   1.4741   -.6492  -1.6949
 Off-diagonal
   -5.8258   2.6240    .9163
