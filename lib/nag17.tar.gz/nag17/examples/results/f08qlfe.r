 F08QLF Example Program Results
 
 S
       9.9D-01    7.0D-01    7.0D-01    5.7D-01
 
 SEP
       6.3D-01    3.7D-01    3.7D-01    3.1D-01
 
 Approximate error estimates for eigenvalues of T (machine-dependent)
       9.6D-17    1.4D-16    1.4D-16    1.7D-16
 
 Approximate error estimates for right eigenvectors of T (machine-dependent)
       1.5D-16    2.6D-16    2.6D-16    3.1D-16
