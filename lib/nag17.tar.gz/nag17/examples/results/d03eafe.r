 D03EAF Example Program Results
 
 Interior Neumann problem
 
 Total integral =          16.00
 
 Nodes
            X              Y              PHI            PHID
            1.50           2.00           1.00            .00
           -1.50           2.00           1.00            .00
             .00            .00           1.00            .00
             .00           1.00           1.00            .00
           -1.00           2.00           1.00            .00
            1.00           2.00           1.00            .00
 
 Selected points
            X              Y              PHI
            2.00           1.00           1.00
            2.50            .50           1.00
            3.00            .00           1.00
