 F07AHF Example Program Results
 
 Solution(s)
             1          2
 1      1.0000     3.0000
 2     -1.0000     2.0000
 3      3.0000     4.0000
 4     -5.0000     1.0000
 
 Backward errors (machine-dependent)
       5.6D-17    6.2D-17
 Estimated forward error bounds (machine-dependent)
       2.4D-14    3.3D-14
