 G02ECF Example Program Results
 
 Number of     CP      RSQ         MODEL
 parameters
 
       0      55.45   .0000 
       1      56.84   .0082  TKN
       1      20.33   .5054  TVS
       1      13.50   .5983  BOD
       1       6.57   .6926  COD
       1       6.29   .6965  TS 
       2      21.36   .5185  TKN TVS
       2      11.33   .6551  BOD TVS
       2       9.09   .6856  BOD TKN
       2       7.70   .7045  BOD COD
       2       7.33   .7095  TKN TS 
       2       7.16   .7119  TS  TVS
       2       6.88   .7157  BOD TS 
       2       6.87   .7158  TKN COD
       2       5.27   .7376  TVS COD
       2       1.74   .7857  TS  COD
       3       8.68   .7184  BOD TKN TVS
       3       8.16   .7255  TKN TS  TVS
       3       8.15   .7256  BOD TS  TVS
       3       7.15   .7392  BOD TVS COD
       3       6.51   .7479  BOD TKN COD
       3       6.25   .7515  BOD TKN TS 
       3       5.67   .7595  TKN TVS COD
       3       3.44   .7898  BOD TS  COD
       3       3.42   .7900  TS  TVS COD
       3       2.32   .8050  TKN TS  COD
       4       7.70   .7591  BOD TKN TS  TVS
       4       6.78   .7716  BOD TKN TVS COD
       4       5.07   .7948  BOD TS  TVS COD
       4       4.32   .8050  BOD TKN TS  COD
       4       4.00   .8094  TKN TS  TVS COD
       5       6.00   .8094  BOD TKN TS  TVS COD
