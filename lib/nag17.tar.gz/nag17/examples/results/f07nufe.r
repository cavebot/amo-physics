 F07NUF Example Program Results
 
 Estimate of condition number =  1.57D+01
