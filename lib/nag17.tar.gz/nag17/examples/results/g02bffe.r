 G02BFF Example Program Results
 
 Number of variables (columns) = 3
 Number of cases     (rows)    = 5
 
 Data matrix is:-
 
            1           2           3
   1      2.0000      3.0000      3.0000
   2      4.0000      6.0000      4.0000
   3      9.0000      9.0000       .0000
   4       .0000     12.0000      2.0000
   5     12.0000     -1.0000      5.0000
 
 Variable   Mean    St. dev.
     1     6.7500     4.5735
     2     7.5000     3.8730
     3     3.5000     1.2910
 
 Sums of squares and cross-products about zero
            1           2           3
   1    245.0000    111.0000     82.0000
   2    111.0000    270.0000     57.0000
   3     82.0000     57.0000     54.0000
 
 Correlation-like coefficients
            1           2           3
   1      1.0000       .9840       .9055
   2       .9840      1.0000       .7699
   3       .9055       .7699      1.0000
 
 Minimum number of cases used for any pair of variables:  3
 
 Numbers used for each pair are:
            1           2           3
   1      4.0000      3.0000      3.0000
   2      3.0000      4.0000      3.0000
   3      3.0000      3.0000      4.0000
