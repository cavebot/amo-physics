 E04CCF Example Program Results
 
 Final function value is        .0000
 at the point       .5000      -.9999
 This has error number  0
