 F07BGF Example Program Results
 
 Estimate of condition number =  5.64D+01
