 E02ZAF Example Program Results
 
 Panel   1
     .00    .77
     .21    .44
     .54    .04
 
 Panel   2
     .70   1.06
 
 Panel   3
     .71   1.95
 
 Panel   4
    1.44    .33
    1.01    .50
    1.84    .02
    1.53    .18
 
 Panel   5
 
 Panel   6
    1.00   1.20
