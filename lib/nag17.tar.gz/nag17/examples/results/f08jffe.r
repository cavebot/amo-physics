 F08JFF Example Program Results
 
 Eigenvalues
    -7.0037  -.4059  2.0028  8.9968
