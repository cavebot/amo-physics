 G13AFF Example Program Results
 
 Convergence was achieved after 25 cycles
 
 Final values of the PAR parameters and the constant are as follows
     -.0543    -.5548    -.6734    9.9848
 
 Residual sum of squares is  9397.220  with  25 degrees of freedom
 
 The corresponding SD array holds
     .3457    .2636    .1665   7.4170
 
 The correlation matrix is as follows
       1.000       .807       .355      -.040
        .807      1.000       .468      -.049
        .355       .468      1.000      -.038
       -.040      -.049      -.038      1.000
 
 The residuals consist of  29 values
    19.6275   -5.3093    9.7983   15.2412   -9.1693
    16.1107   15.3929   -5.4500  -27.6205  -18.1306
     5.7202  -13.0881  -22.7151  -14.9256    4.6930
    33.5406   19.7138  -27.3360   32.1231  -11.7681
     1.1524   -1.7756   23.6821  -10.6238   13.9619
    -5.2727  -28.7868  -20.6573   -2.2555
 
 The state set consists of  4 values
      64.000    -30.985    -20.657     -2.256
