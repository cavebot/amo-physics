 F04AXF Example Program Results
 
 On exit from F01BRF
 Value of W(1) =   18.0000
 
 On exit from F04AXF
  Solution
    3.0000
    3.0000
    6.0000
    6.0000
    3.0000
    1.0000
