 E04HFF Example Program Results
 
 On exit, the sum of squares is       .0082
 at the point       .0824      1.1330      2.3437
