 G02GNF Example Program Results
 
 Deviance =    .9038D+01
 Degrees of freedom =  8
 
       Estimate     Standard error
 
         2.5977         .0258
         1.2619         .0438
         1.2777         .0436
          .0580         .0668
         1.0307         .0551
          .2910         .0732
          .9876         .0559
          .4880         .0675
         -.1996         .0904
 
 Function    1
     1.00    1.00     .00     .00    1.00
      .00     .00     .00     .00
 
 STAT =     4.8903 SE =      .0674 Z =    72.5934
 
 Function    2
      .00    1.00   -1.00     .00     .00
      .00     .00     .00     .00
 
 STAT =     -.0158 SE =      .0672 Z =     -.2350
 
 Function    3
      .00    1.00     .00     .00     .00
      .00     .00     .00     .00
 
 Function not estimable
