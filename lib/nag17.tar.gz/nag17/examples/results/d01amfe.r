 D01AMF Example Program Results
 
 A      - lower limit of integration =      .0000
 B      - upper limit of integration = infinity
 EPSABS - absolute accuracy requested =   .00D+00
 EPSREL - relative accuracy requested =   .10D-03
 
 RESULT - approximation to the integral =   3.14159
 ABSERR - estimate of the absolute error =   .27D-04
 KOUNT  - number of function evaluations =  285
 IW(1)  - number of subintervals used =   10
