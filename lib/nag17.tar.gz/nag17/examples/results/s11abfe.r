 S11ABF Example Program Results
 
      X           Y        IFAIL
 
   -2.000D+00  -1.444D+00      0
   -5.000D-01  -4.812D-01      0
    1.000D+00   8.814D-01      0
    6.000D+00   2.492D+00      0
