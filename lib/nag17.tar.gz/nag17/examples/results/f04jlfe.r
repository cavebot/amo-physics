 F04JLF Example Program Results
 
 Least-squares solution
    2.0000  -1.0000  -3.0000
