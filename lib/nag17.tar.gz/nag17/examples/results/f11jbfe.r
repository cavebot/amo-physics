 F11JBF Example Program Results
  Solution of linear system
        .7000D+00
        .1600D+00
        .5200D+00
        .7700D+00
        .2800D+00
        .2100D+00
        .9300D+00
        .2000D+00
        .9000D+00
