 G02BCF Example Program Results
 
 Number of variables (columns) = 3
 Number of cases     (rows)    = 5
 
 Data matrix is:-
 
            1           2           3
   1      2.0000      3.0000      3.0000
   2      4.0000      6.0000      4.0000
   3      9.0000      9.0000       .0000
   4       .0000     12.0000      2.0000
   5     12.0000     -1.0000      5.0000
 
 Variable   Mean    St. dev.
     1     6.7500     4.5735
     2     7.5000     3.8730
     3     3.5000     1.2910
 
 Sums of squares and cross-products of deviations
            1           2           3
   1     62.7500     21.0000     10.0000
   2     21.0000     45.0000     -6.0000
   3     10.0000     -6.0000      5.0000
 
 Correlation coefficients
            1           2           3
   1      1.0000       .9707       .9449
   2       .9707      1.0000      -.6547
   3       .9449      -.6547      1.0000
 
 Minimum number of cases used for any pair of variables:  3
 
 Numbers used for each pair are:
            1           2           3
   1      4.0000      3.0000      3.0000
   2      3.0000      4.0000      3.0000
   3      3.0000      3.0000      4.0000
