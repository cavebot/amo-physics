 G02BDF Example Program Results
 
 Number of variables (columns) = 3
 Number of cases     (rows)    = 5
 
 Data matrix is:-
 
            1           2           3
   1      2.0000      3.0000      3.0000
   2      4.0000      6.0000      4.0000
   3      9.0000      9.0000       .0000
   4       .0000     12.0000      2.0000
   5     12.0000     -1.0000      5.0000
 
 Variable   Mean    St. dev.
     1     5.4000     4.9800
     2     5.8000     5.0695
     3     2.8000     1.9235
 
 Sums of squares and cross-products about zero
            1           2           3
   1    245.0000     99.0000     82.0000
   2     99.0000    271.0000     52.0000
   3     82.0000     52.0000     54.0000
 
 Correlation-like coefficients
            1           2           3
   1      1.0000       .3842       .7129
   2       .3842      1.0000       .4299
   3       .7129       .4299      1.0000
