 G02CAF Example Program Results
 
  Case     Independent     Dependent
 number     variable       variable
 
    1         1.0000        20.0000
    2          .0000        15.5000
    3         4.0000        28.3000
    4         7.5000        45.0000
    5         2.5000        24.5000
    6          .0000        10.0000
    7        10.0000        99.0000
    8         5.0000        31.2000
 
 Mean of independent variable               =   3.7500
 Mean of   dependent variable               =  34.1875
 Standard deviation of independent variable =   3.6253
 Standard deviation of   dependent variable =  28.2604
 Correlation coefficient                    =    .9096
 
 Regression coefficient                     =   7.0905
 Standard error of coefficient              =   1.3224
 t-value for coefficient                    =   5.3620
 
 Regression constant                        =   7.5982
 Standard error of constant                 =   6.6858
 t-value for constant                       =   1.1365
 
 Analysis of regression table :-
 
       Source        Sum of squares  D.F.    Mean square     F-value
 
 Due to regression     4625.3033      1.     4625.3033       28.7511
 About  regression      965.2454      6.      160.8742
 Total                 5590.5488      7.
