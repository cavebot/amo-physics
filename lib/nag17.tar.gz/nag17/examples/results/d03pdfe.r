 D03PDF Example Program Results
 Polynomial degree =   3   No. of elements =    9
 Accuracy requirement =  .100D-03  Number of points =    28

  T /   X    -1.0000  -.6000  -.2000   .2000   .6000  1.0000

  .0001 U(1)  1.0000   .8090   .3090  -.3090  -.8090 -1.0000
        U(2) -2.4850 -1.9957  -.7623   .7623  1.9957  2.4850

  .0010 U(1)  1.0000   .8085   .3088  -.3088  -.8085 -1.0000
        U(2) -2.5583 -1.9913  -.7606   .7606  1.9913  2.5583

  .0100 U(1)  1.0000   .8051   .3068  -.3068  -.8051 -1.0000
        U(2) -2.6962 -1.9481  -.7439   .7439  1.9481  2.6962

  .1000 U(1)  1.0000   .7951   .2985  -.2985  -.7951 -1.0000
        U(2) -2.9022 -1.8339  -.6338   .6338  1.8339  2.9022

 1.0000 U(1)  1.0000   .7939   .2972  -.2972  -.7939 -1.0000
        U(2) -2.9233 -1.8247  -.6120   .6120  1.8247  2.9233

 Number of integration steps in time                    50
 Number of residual evaluations of resulting ODE system 407
 Number of Jacobian evaluations                          18
 Number of iterations of nonlinear solver               122

