 G02BTF Example Program Results
 
 ---------------------------------------------
 Observation:    3      Weight =         .3700
 ---------------------------------------------
 
 Means
         1.3299         .3334         .9874
 
 Sums of squares and cross-products
             1          2          3
 1      8.7569     3.6978     4.0707
 2                 1.5905     1.6861
 3                            1.9297
 
 Variance matrix
             1          2          3
 1     10.8512     4.5822     5.0443
 2                 1.9709     2.0893
 3                            2.3912
