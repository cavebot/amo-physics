 D03PPF Example Program Results


  Accuracy requirement =  .500D-04 Number of points =  61

  Remeshing every  3 time steps

  E =    .005
 
 T =   .200
 X               .3000    .4000    .5000    .6000    .7000
 Approx sol.     .9968    .7448    .4700    .1667    .1018
 Exact  sol.     .9967    .7495    .4700    .1672    .1015

 T =   .400
 X               .4000    .5000    .6000    .7000    .8000
 Approx sol.    1.0003    .9601    .4088    .1154    .1005
 Exact  sol.     .9997    .9615    .4094    .1157    .1003

 T =   .600
 X               .6000    .6500    .7000    .7500    .8000
 Approx sol.     .9966    .9390    .3978    .1264    .1037
 Exact  sol.     .9964    .9428    .4077    .1270    .1033

 T =   .800
 X               .7000    .7500    .8000    .8500    .9000
 Approx sol.    1.0003    .9872    .5450    .1151    .1010
 Exact  sol.     .9996    .9878    .5695    .1156    .1008

 T =  1.000
 X               .8000    .8500    .9000    .9500   1.0000
 Approx sol.    1.0001    .9961    .7324    .1245    .1004
 Exact  sol.     .9999    .9961    .7567    .1273    .1004

 Number of integration steps in time =    205
 Number of function evaluations =   4872
 Number of Jacobian evaluations =    71
 Number of iterations =    518

