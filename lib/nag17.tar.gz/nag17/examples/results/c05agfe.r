 C05AGF Example Program Results
 
 Root is        .56714
 Interval searched is (  .50000,  .90000)
