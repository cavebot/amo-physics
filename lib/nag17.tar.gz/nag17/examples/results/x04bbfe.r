 X04BBF Example Program Results
 
    20      2.996
