 G05DDF Example Program Results
 
     1.8045
     2.9393
     3.3701
      .9602
     3.2751
