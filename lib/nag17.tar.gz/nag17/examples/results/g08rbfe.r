 G08RBF Example Program Results
 
 Number of samples = 1
 Number of parameters fitted = 1
 Distribution power parameter =    .00001
 Tolerance for ties =    .00001
 
 Score statistic
     4.584
 
 Covariance matrix of score statistic
     7.653
 
 Parameter estimates
      .599
 
 Covariance matrix of parameter estimates
      .131
 
 Chi-squared statistic =    2.746 with 1 d.f.
 
 Standard errors of estimates and
 approximate z-statistics
      .361         1.657
