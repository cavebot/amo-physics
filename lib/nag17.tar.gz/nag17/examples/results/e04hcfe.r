 E04HCF Example Program Results
 
 The test point is
     1.4600    -.8200     .5700    1.2100
 
 1st derivatives are consistent with function values
 
 At the test point, FUNCT gives the function value  6.2273D+01
 and the 1st derivatives
   -1.285D+01  -1.649D+02   5.384D+01   5.775D+00
