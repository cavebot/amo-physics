 G11SBF Example Program Results
 
 Frequency     Score pattern
 
     4             F F F
     1             F T F
     1             T T T
     2             F F T
     1             T T F
     1             F T T
