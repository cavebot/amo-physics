 G01NBF Example Program Results
 
 N =  10 BETA =   .800 Y0 =  1.000
 
       Moments
 
  1    .682D+00
  2    .536D+00
  3    .443D+00
