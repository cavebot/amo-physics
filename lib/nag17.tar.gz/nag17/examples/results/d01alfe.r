 D01ALF Example Program Results
 
 A      - lower limit of integration =      .0000
 B      - upper limit of integration =     1.0000
 EPSABS - absolute accuracy requested =   .00D+00
 EPSREL - relative accuracy requested =   .10D-02
 POINTS(1) - given break-point =      .1429
 
   RESULT - approximation to the integral =   2.60757
   ABSERR - estimate of the absolute error =   .62D-13
   KOUNT  - number of function evaluations =  462
 IW(1)  - number of subintervals used =   12
