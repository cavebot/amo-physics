 F08QYF Example Program Results
 
 S
       9.9D-01    1.0D+00    9.8D-01    9.8D-01
 
 SEP
       8.4D+00    8.0D+00    5.8D+00    5.8D+00
 
 Approximate error estimates for eigenvalues of T (machine-dependent)
       1.0D-15    1.0D-15    1.1D-15    1.1D-15
 
 Approximate error estimates for right eigenvectors of T (machine-dependent)
       1.2D-16    1.3D-16    1.8D-16    1.8D-16
