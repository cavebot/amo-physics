 G03ECF Example Program Results
 
   Distance   Clusters Joined
 
     1.000     B  D  
     2.000     A  C  
     6.500     A  E  
    14.125     A  B  
 
 Dendrogram
 
    14.125           -------                                               
                     I     I                                               
                     I     I                                               
    12.006           I     I                                               
                     I     I                                               
                     I     I                                               
     9.887           I     I                                               
                     I     I                                               
                     I     I                                               
     7.769           I     I                                               
                  ---*     I                                               
                  I  I     I                                               
     5.650        I  I     I                                               
                  I  I     I                                               
                  I  I     I                                               
     3.531        I  I     I                                               
                  I  I     I                                               
               ---*  I     I                                               
     1.412     I  I  I  ---*                                               
               I  I  I  I  I                                               
 
               A  C  E  B  D  
