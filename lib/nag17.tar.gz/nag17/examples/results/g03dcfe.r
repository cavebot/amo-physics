 G03DCF Example Program Results
 
    Obs       Posterior        Allocated     Atypicality
              probabilities    to group      index
 
      1       .094  .905  .002     2       .596  .254  .975
      2       .005  .168  .827     3       .952  .836  .018
      3       .019  .920  .062     2       .954  .797  .912
      4       .697  .303  .000     1       .207  .860  .993
      5       .317  .013  .670     3       .991 1.000  .984
      6       .032  .366  .601     3       .981  .978  .887
