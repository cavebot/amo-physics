 X04EBF Example Program Results
 
 Example 1:
     1  2  3  4  5
 1  11 12 13 14 15
 2  21 22 23 24 25
 3  31 32 33 34 35
 
 Example 2:
               Un    Deux   Trois  Quatre    Cinq
     Uno       11      12      13      14      15
     Duo               22      23      24      25
     Tre                       33      34      35
 Quattro                               44      45
  Cinque                                       55
