 G13ASF Example Program Results
 
 RESIDUAL AUTOCORRELATION FUNCTION
 ---------------------------------
 
 LAG  K      1      2      3      4      5      6      7
 R(K)       .020  -.040  -.019   .068  -.143  -.046  -.205
 ST.ERROR   .007   .125   .128   .150   .168   .168   .178
 ---------------------------------------------------------
 LAG  K      8      9     10
 R(K)      -.108  -.001  -.058
 ST.ERROR   .179   .181   .183
 ---------------------------------------------------------
 
 BOX - LJUNG PORTMANTEAU STATISTIC =      3.465
                SIGNIFICANCE LEVEL =       .839
 (BASED ON   7 DEGREES OF FREEDOM)
 
 VALUE OF IFAIL PARAMETER ON EXIT FROM G13ASF =   0
