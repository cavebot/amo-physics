 E04HDF Example Program Results
 
 The test point is
    1.4600   -.8200    .5700   1.2100
 
 2nd derivatives are consistent with 1st derivatives
 
 At the test point, FUNCT gives the function value  6.2273D+01
 and the 1st derivatives
   -1.285D+01  -1.649D+02   5.384D+01   5.775D+00
 
 HESS gives the lower triangle of the Hessian matrix
    9.500D+00
    2.000D+01   2.461D+02
    0.000D+00  -9.220D+01   1.944D+02
   -7.500D+00   0.000D+00  -1.000D+01   1.750D+01
