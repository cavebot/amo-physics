 F01QFF Example Program Results
 
 QR factorization of A
 
 Vector ZETA
   1.2101   1.0948   1.3388
 
 Matrix A after factorization (upper triangular part is R)
  -5.3852  -2.2283  -2.2283
    .3836  -3.3218   -.9135
    .4297    .0271   2.6833
    .0767    .4762    .4545
   -.4450    .7576   -.0318
 
 Array of interchanges
        3        3        3
