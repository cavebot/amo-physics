 G01ERF Example Program Results
 
 P =      .6141
 P =      .9983
 P =      .7944
 P =      .1016
