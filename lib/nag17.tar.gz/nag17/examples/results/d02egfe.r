 D02EGF Example Program Results
 
 Calculation with TOL =  .1D-02
  Y(1)-VAL changes sign at X =  4.377
 
 Calculation with TOL =  .1D-03
  Y(1)-VAL changes sign at X =  4.377
