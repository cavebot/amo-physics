 S11ACF Example Program Results
 
      X            Y        IFAIL
 
    1.000D+00   0.000D+00      0
    2.000D+00   1.317D+00      0
    5.000D+00   2.292D+00      0
    1.000D+01   2.993D+00      0
   -5.000D-01   0.000D+00      1
