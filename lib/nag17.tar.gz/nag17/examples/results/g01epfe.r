 G01EPF Example Program Results 
 
  Durbin-Watson statistic      .9238
 
  Probability for the lower bound =      .0610
  Probability for the upper bound =      .0060
