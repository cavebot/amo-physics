 M01ZBF Example Program Results
 
 Numbers in rank order
 
     1.2    1.7    3.2    4.3    4.5    4.6    5.3    5.3    7.6    7.8
     7.8    9.9
