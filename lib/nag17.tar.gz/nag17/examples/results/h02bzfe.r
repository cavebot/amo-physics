 H02BZF Example Program Results


 IP objective value =        97.00    


 Varbl   State     Value     Lower Bound   Upper Bound    Lagr Mult   Residual

 Oatmeal   EQ      4.000         4.000         4.000       3.000      0.0000E+00
 Chicken   LL     0.0000E+00    0.0000E+00     3.000       24.00      0.0000E+00
 Eggs      LL     0.0000E+00    0.0000E+00     2.000       13.00      0.0000E+00
 Milk      LL      5.000         5.000         8.000       9.000      0.0000E+00
 Pie       EQ      2.000         2.000         2.000       20.00      0.0000E+00
 Bacon     LL     0.0000E+00    0.0000E+00     2.000       19.00      0.0000E+00


 L Con   State     Value     Lower Bound   Upper Bound    Lagr Mult   Residual

 Energy    FR      2080.         2000.         None       0.0000E+00   80.00    
 Protein   FR      64.00         55.00         None       0.0000E+00   9.000    
 Calcium   FR      1477.         800.0         None       0.0000E+00   677.0    


 Increase the energy requirements from   2000.      to   2200.    


 IP objective value =        106.0    


 Varbl   State     Value     Lower Bound   Upper Bound    Lagr Mult   Residual

 Oatmeal   EQ      4.000         4.000         4.000       3.000      0.0000E+00
 Chicken   LL     0.0000E+00    0.0000E+00     3.000       24.00      0.0000E+00
 Eggs      LL     0.0000E+00    0.0000E+00     2.000       13.00      0.0000E+00
 Milk      LL      6.000         6.000         8.000       9.000      0.0000E+00
 Pie       EQ      2.000         2.000         2.000       20.00      0.0000E+00
 Bacon     LL     0.0000E+00    0.0000E+00     2.000       19.00      0.0000E+00


 L Con   State     Value     Lower Bound   Upper Bound    Lagr Mult   Residual

 Energy    FR      2240.         2200.         None       0.0000E+00   40.00    
 Protein   FR      72.00         55.00         None       0.0000E+00   17.00    
 Calcium   FR      1762.         800.0         None       0.0000E+00   962.0    
