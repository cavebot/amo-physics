 F06TMF Example Program Results

 F06TMF Example Program ends OK
