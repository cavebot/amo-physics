 D02EAF Example Program Results
 
 Calculation with TOL =  .1D-02
     X         Y(1)         Y(2)         Y(3)
     .00      1.00000       .00000       .00000
   10.00       .84136       .00002       .15862
 
 Calculation with TOL =  .1D-03
     X         Y(1)         Y(2)         Y(3)
     .00      1.00000       .00000       .00000
   10.00       .84136       .00002       .15863
