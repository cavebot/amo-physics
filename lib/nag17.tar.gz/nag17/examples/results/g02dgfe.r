 G02DGF Example Program Results
 Results from G02DAF
 
 Model not of full rank
 
 Residual sum of squares =    .2223D+02
 Degrees of freedom =    8
 
 Variable   Parameter estimate   Standard error
 
      1           .3056D+02           .3849D+00
      2           .5447D+01           .8390D+00
      3           .6743D+01           .8390D+00
      4           .1105D+02           .8390D+00
      5           .7320D+01           .8390D+00
 
 Results for second y-variable using G02DGF
 
 Residual sum of squares =    .2400D+02
 Degrees of freedom =    8
 
 Variable   Parameter estimate   Standard error
 
      1           .5407D+02           .4000D+00
      2           .1127D+02           .8718D+00
      3           .1260D+02           .8718D+00
      4           .1693D+02           .8718D+00
      5           .1327D+02           .8718D+00
