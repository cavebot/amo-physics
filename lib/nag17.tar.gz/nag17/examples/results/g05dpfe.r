 G05DPF Example Program Results
 
      .4585
     2.9769
     1.9816
     2.9830
      .2585
