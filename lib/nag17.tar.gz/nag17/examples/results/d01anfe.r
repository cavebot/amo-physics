 D01ANF Example Program Results
 
 A      - lower limit of integration =      .0000
 B      - upper limit of integration =     1.0000
 EPSABS - absolute accuracy requested =   .00D+00
 EPSREL - relative accuracy requested =   .10D-03
 
 RESULT - approximation to the integral =   -.12814
 ABSERR - estimate of the absolute error =   .36D-05
 KOUNT  - number of function evaluations =  275
 IW(1)  - number of subintervals used =    8
