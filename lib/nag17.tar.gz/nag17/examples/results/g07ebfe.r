 G07EBF Example Program Results
 
  Location estimator     Confidence Interval 
 
        .9505            (  .5650 , 1.3050 )
 
  Corresponding Mann-Whitney U statistics
 
 Lower :  2007.00
 Upper :  2993.00
