 D02CGF Example Program Results
 
 Calculation with TOL =  .1D-03
  Y(M) changes sign at X =  7.2883
 
 Calculation with TOL =  .1D-04
  Y(M) changes sign at X =  7.2882
