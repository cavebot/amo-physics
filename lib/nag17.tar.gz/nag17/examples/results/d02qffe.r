 D02QFF Example Program Results
 
 Root at   0.00000D+00
 for event equation  2 with type  1 and residual   0.00000D+00
  Y(1) =   0.00000D+00   Y'(1) =   1.00000D+00
 
 Root at   1.57076D+00
 for event equation  1 with type  1 and residual  -5.68751D-16
  Y(1) =   1.00003D+00   Y'(1) =  -5.68751D-16
 
 Root at   3.14151D+00
 for event equation  2 with type  1 and residual  -1.31450D-15
  Y(1) =  -1.31450D-15   Y'(1) =  -1.00012D+00
 
 Root at   4.71228D+00
 for event equation  1 with type  1 and residual   1.70937D-15
  Y(1) =  -1.00010D+00   Y'(1) =   1.70937D-15
 
 Root at   6.28306D+00
 for event equation  2 with type  1 and residual   1.25262D-16
  Y(1) =   1.25262D-16   Y'(1) =   9.99979D-01
 
 Root at   7.85379D+00
 for event equation  1 with type  1 and residual  -3.21293D-15
  Y(1) =   9.99970D-01   Y'(1) =  -3.21293D-15
 
 Root at   9.42469D+00
 for event equation  2 with type  1 and residual  -2.71471D-15
  Y(1) =  -2.71471D-15   Y'(1) =  -9.99854D-01
