 G13AAF Example Program Results
 
 Non-seasonal differencing of order 2 and seasonal differencing
 of order 1 with seasonality 4 are applied
 
 The output array holds 20 values, of which the first 14 are differenced values
 
     -11.0    -10.0     -8.0      4.0     12.0
      -2.0     18.0      9.0     -4.0     -6.0
      -5.0     -2.0    -12.0      5.0      2.0
     -10.0    -13.0     17.0      6.0    105.0
