 F06QRF Example Program Results

 F06QRF Example Program ends OK
