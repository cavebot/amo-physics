 F04KMF Example Program Results
 
 Constrained least-squares solution
    ( 1.0789,-1.9523) ( -.7581, 3.7203) ( 1.0789,-1.9523) ( -.7581, 3.7203)
 
 Residual sum of squares =   1.75D+02
