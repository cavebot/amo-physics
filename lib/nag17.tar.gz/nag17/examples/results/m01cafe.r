 M01CAF Example Program Results
 
 Sorted numbers
 
      .5     .5    1.1    1.2    1.3    1.3    2.1    2.3    2.3    4.1
     5.8    5.9    6.5    6.5    8.6    9.9
