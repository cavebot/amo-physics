 F01QGF Example Program Results
 
 RQ factorization of A
 
 Vector ZETA
   1.2649   1.3416   1.1547
 
 Matrix A after factorization (R is in left-hand upper triangle)
  -4.0000  -1.0000  -1.0000    .6325    .0000
    .0000  -2.0000    .0000    .0000   -.4472
    .0000    .0000  -3.0000    .5774    .5774
