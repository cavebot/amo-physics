 A02ABF Example Program Results
 
    XR    XI       Y
   -1.7   2.6   3.1064
