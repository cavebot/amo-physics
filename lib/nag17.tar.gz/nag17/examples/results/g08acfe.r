 G08ACF Example Program Results
 
 Median test
 
 Data values
 
     Group 1   13.  6. 12.  7. 12.  7. 10.  7.
               10.  7. 10.  7. 10.  8.  9.  8.
 
     Group 2   17.  6. 16.  8. 15.  8. 15. 10.
               15. 10. 14. 10. 14. 11. 14. 11.
               13. 12. 13. 12. 13. 12. 12.
 
     13 scores below median in group 1
      6 scores below median in group 2
 
      Significance    .00088
