 F06THF Example Program Results

 F06THF Example Program ends OK
