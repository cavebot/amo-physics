 G13ADF Example Program Results
 
 Parameter estimation success/failure indicator   0   1   0   1
 
 ARIMA model parameter values     .37390    .51237
 
 Residual variance    .00148
