 S09AAF Example Program Results
 
      X           Y        IFAIL
 
   -5.000D-01  -5.236D-01      0
    1.000D-01   1.002D-01      0
    9.000D-01   1.120D+00      0
    2.000D+00   0.000D+00      1
   -1.500D+00   0.000D+00      1
